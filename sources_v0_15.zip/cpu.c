#include "cpu.h"
u8 *rom; u32 romsize; u8 wram[0x20000]; u8 sram[0x8000];
u16 A,X,Y,S,D,PC; u8 DB,PB,P,E=1; int waiting=0,stopped=0; long cycles=0;
unsigned char wr7f[0x10000]; unsigned char wrlow[0x2000]; u8 *romtrace; int tracing=0; int dataread=0;
extern u8 io_read(u16 a); extern void io_write(u16 a,u8 v);
#define FN 0x80
#define FV 0x40
#define FM 0x20
#define FX 0x10
#define FD 0x08
#define FI 0x04
#define FZ 0x02
#define FC 0x01
static inline u32 romoff(u32 bank,u32 off){ return (((bank&0x7F)*0x8000u)+(off&0x7FFF))%romsize; }
u8 read8(u32 a){
  u32 bank=(a>>16)&0xFF, off=a&0xFFFF;
  if(bank==0x7E) return wram[off];
  if(bank==0x7F) return wram[0x10000+off];
  if((bank&0x7F)<0x40){
    if(off<0x2000) return wram[off];
    if(off<0x6000) return io_read(off);
    if(off<0x8000) return 0;
  } else if((bank&0x7F)>=0x70 && (bank&0x7F)<0x7E && off<0x8000) return sram[off&0x1FFF];
  u32 o=romoff(bank,off);
  if(tracing && dataread) romtrace[o]=1;
  { extern long watch_lo, watch_hi; if(dataread && (long)o>=watch_lo && (long)o<=watch_hi){ extern long frame; extern long wf1,wf2; static int n=0; if(frame>=wf1 && frame<=wf2 && n<400000){ n++; fprintf(stderr,"WATCH f%ld read %06X (rom %05X) from PC %02X:%04X A=%04X X=%04X Y=%04X\n",frame,a,o,PB,(u16)(PC-1),A,X,Y);} } }
  return rom[o];
}
long wf1=0,wf2=999999999; long mvlo=-1,mvhi=-1; long wrlo=-1,wrhi=-1; int wrval=-1;
void write8(u32 a,u8 v){
  u32 bank=(a>>16)&0xFF, off=a&0xFFFF;
  if(wrlo>=0 && bank<0x40 && (long)off>=wrlo && (long)off<=wrhi && (wrval<0||wrval==v)){ extern long frame; static int wn=0; if(wn<200){wn++; fprintf(stderr,"WR f%ld %04X<-%02X PC %02X:%04X ptr=%02X:%02X%02X\n",frame,off,v,PB,(u16)(PC-1),wram[0xBB],wram[0xBA],wram[0xB9]);} }
  { extern unsigned char wrlow[0x2000]; if(off<0x2000) wrlow[off]=1; extern long wwatch; if(wwatch>=0 && bank<0x40 && off==wwatch){ extern long frame; static int n=0; if(n<100000){n++; fprintf(stderr,"WWATCH f%ld write %02X to %04X from PC %02X:%04X\n",frame,v,off,PB,(u16)(PC-1));} } }
  if(bank==0x7E){wram[off]=v;return;}
  if(bank==0x7F){ extern unsigned char wr7f[0x10000]; wr7f[off]=1; wram[0x10000+off]=v;return;}
  if((bank&0x7F)<0x40){
    if(off<0x2000){wram[off]=v;return;}
    if(off<0x6000){io_write(off,v);return;}
    return;
  }
  if((bank&0x7F)>=0x70 && (bank&0x7F)<0x7E && off<0x8000){sram[off&0x1FFF]=v;}
}
static inline u16 read16(u32 a){ dataread=1; u16 r=read8(a)|(read8((a+1)&0xFFFFFF)<<8); return r; }
static inline u16 read16b0(u32 a){ dataread=1; return read8(a&0xFFFF)|(read8((a+1)&0xFFFF)<<8); }
static inline void write16(u32 a,u16 v){ write8(a,v&0xFF); write8((a+1)&0xFFFFFF,v>>8); }
static inline void write16b0(u32 a,u16 v){ write8(a&0xFFFF,v&0xFF); write8((a+1)&0xFFFF,v>>8); }
static inline u8 fetch8(void){ dataread=0; u8 v=read8(((u32)PB<<16)|PC); PC++; return v; }
static inline u16 fetch16(void){ u8 l=fetch8(); u8 h=fetch8(); return l|(h<<8); }
static inline u32 fetch24(void){ u8 l=fetch8(); u8 m=fetch8(); u8 h=fetch8(); return l|(m<<8)|(h<<16); }
#define M8 (P&FM)
#define X8 (P&FX)
static inline void setNZ8(u8 v){ P&=~(FN|FZ); if(v&0x80)P|=FN; if(!v)P|=FZ; }
static inline void setNZ16(u16 v){ P&=~(FN|FZ); if(v&0x8000)P|=FN; if(!v)P|=FZ; }
static inline void setNZm(u16 v){ if(M8) setNZ8(v); else setNZ16(v); }
static inline void setNZx(u16 v){ if(X8) setNZ8(v); else setNZ16(v); }
static void push8(u8 v){ write8(S,v); S--; if(E) S=0x100|(S&0xFF); }
static u8 pull8(void){ S++; if(E) S=0x100|(S&0xFF); dataread=1; return read8(S); }
static void push16(u16 v){ push8(v>>8); push8(v&0xFF); }
static u16 pull16(void){ u8 l=pull8(); u8 h=pull8(); return l|(h<<8); }
static void setP(u8 v){ P=v; if(E) P|=0x30; if(P&FX){ X&=0xFF; Y&=0xFF; } }
void cpu_reset(void){
  E=1; P=0x34; S=0x1FF; D=0; DB=0; PB=0; A=X=Y=0;
  dataread=1; PC=read8(0xFFFC)|(read8(0xFFFD)<<8);
}
static void interrupt(u32 vec_native,u32 vec_emu,int brk){
  if(E){ push16(PC); push8(brk?(P|0x10):(P&~0x10)); }
  else { push8(PB); push16(PC); push8(P); }
  P|=FI; P&=~FD; PB=0; dataread=1;
  u32 v=E?vec_emu:vec_native; PC=read8(v)|(read8(v+1)<<8);
}
void cpu_nmi(void){ waiting=0; interrupt(0xFFEA,0xFFFA,0); }
void cpu_irq(void){ waiting=0; if(!(P&FI)) interrupt(0xFFEE,0xFFFE,0); }

/* effective address helpers */
static u32 ea_dp(u8 o){ return (D+o)&0xFFFF; }
static u32 ea_dpx(u8 o){ return (D+o+(X8?(X&0xFF):X))&0xFFFF; }
static u32 ea_dpy(u8 o){ return (D+o+(X8?(Y&0xFF):Y))&0xFFFF; }
static u32 xv(void){ return X8?(X&0xFF):X; }
static u32 yv(void){ return X8?(Y&0xFF):Y; }
static u32 ea_abs(u16 a){ return ((u32)DB<<16)|a; }
static u32 ea_absx(u16 a){ return (((u32)DB<<16)|a)+xv(); }
static u32 ea_absy(u16 a){ return (((u32)DB<<16)|a)+yv(); }
/* group-1 addressing: returns address; imm handled by caller (bbb==2 cc==1) */
static u32 g1addr(int bbb,int cc,int op){
  u32 r; u8 b; u16 w;
  if(cc==1){
    switch(bbb){
      case 0: b=fetch8(); { u32 p=ea_dpx(b); r=((u32)DB<<16)+read16b0(p); } return r&0xFFFFFF;
      case 1: b=fetch8(); return ea_dp(b);
      case 3: w=fetch16(); return ea_abs(w);
      case 4: b=fetch8(); { u32 p=ea_dp(b); r=((u32)DB<<16)+read16b0(p)+yv(); } return r&0xFFFFFF;
      case 5: b=fetch8(); return ea_dpx(b);
      case 6: w=fetch16(); return ea_absy(w)&0xFFFFFF;
      case 7: w=fetch16(); return ea_absx(w)&0xFFFFFF;
    }
  } else if(cc==3){
    switch(bbb){
      case 0: b=fetch8(); return (S+b)&0xFFFF;
      case 1: b=fetch8(); { u32 p=ea_dp(b); dataread=1; return read8(p)|(read8((p+1)&0xFFFF)<<8)|(read8((p+2)&0xFFFF)<<16);} 
      case 3: return fetch24();
      case 4: b=fetch8(); { u32 p=(S+b)&0xFFFF; r=((u32)DB<<16)+read16b0(p)+yv(); } return r&0xFFFFFF;
      case 5: b=fetch8(); { u32 p=ea_dp(b); dataread=1; r=(read8(p)|(read8((p+1)&0xFFFF)<<8)|(read8((p+2)&0xFFFF)<<16))+yv(); } return r&0xFFFFFF;
      case 7: return (fetch24()+xv())&0xFFFFFF;
    }
  } else { /* cc==2, bbb==4: (dp) */
    b=fetch8(); u32 p=ea_dp(b); r=((u32)DB<<16)+read16b0(p); return r&0xFFFFFF;
  }
  return 0;
}
static u16 rdm(u32 a){ dataread=1; if(M8) return read8(a); return read16(a); }
static void wrm(u32 a,u16 v){ if(M8) write8(a,v); else write16(a,v); }
static u16 rdx(u32 a){ dataread=1; if(X8) return read8(a); return read16(a); }
static void wrx(u32 a,u16 v){ if(X8) write8(a,v); else write16(a,v); }
static void do_adc(u16 v){
  int c=P&FC;
  if(M8){
    u8 a=A&0xFF,b=v&0xFF; unsigned r;
    if(P&FD){ int lo=(a&0xF)+(b&0xF)+c; if(lo>9)lo+=6; int hi=(a>>4)+(b>>4)+(lo>0xF); r=(lo&0xF); if(hi>9)hi+=6; r|=(hi&0xF)<<4; P&=~(FC|FV); if(hi>0xF)P|=FC; setNZ8(r); }
    else { r=a+b+c; P&=~(FC|FV); if(r>0xFF)P|=FC; if(~(a^b)&(a^r)&0x80)P|=FV; setNZ8(r&0xFF);} 
    A=(A&0xFF00)|(r&0xFF);
  } else {
    u16 a=A,b=v; u32 r;
    if(P&FD){ int cc=c; u32 rr=0; for(int i=0;i<16;i+=4){ int s=((a>>i)&0xF)+((b>>i)&0xF)+cc; if(s>9)s+=6; cc=s>0xF; rr|=(s&0xF)<<i; } r=rr|(cc?0x10000:0); P&=~(FC|FV); if(cc)P|=FC; setNZ16(rr); }
    else { r=(u32)a+b+c; P&=~(FC|FV); if(r>0xFFFF)P|=FC; if(~(a^b)&(a^r)&0x8000)P|=FV; setNZ16(r&0xFFFF);} 
    A=r&0xFFFF;
  }
}
static void do_sbc(u16 v){
  int c=P&FC;
  if(M8){
    u8 a=A&0xFF,b=v&0xFF; unsigned r;
    if(P&FD){ int lo=(a&0xF)-(b&0xF)-(1-c); int bw=0; if(lo<0){lo-=6;bw=1;} int hi=(a>>4)-(b>>4)-bw; r=lo&0xF; int bw2=0; if(hi<0){hi-=6;bw2=1;} r|=(hi&0xF)<<4; P&=~(FC|FV); if(!bw2)P|=FC; setNZ8(r); }
    else { r=a+(u8)~b+c; P&=~(FC|FV); if(r>0xFF)P|=FC; if((a^b)&(a^r)&0x80)P|=FV; setNZ8(r&0xFF);} 
    A=(A&0xFF00)|(r&0xFF);
  } else {
    u16 a=A,b=v; u32 r;
    if(P&FD){ int cc=1-c; u32 rr=0; for(int i=0;i<16;i+=4){ int s=((a>>i)&0xF)-((b>>i)&0xF)-cc; cc=0; if(s<0){s-=6;cc=1;} rr|=(s&0xF)<<i; } P&=~(FC|FV); if(!cc)P|=FC; setNZ16(rr); r=rr; }
    else { r=(u32)a+(u16)~b+c; P&=~(FC|FV); if(r>0xFFFF)P|=FC; if((a^b)&(a^r)&0x8000)P|=FV; setNZ16(r&0xFFFF);} 
    A=r&0xFFFF;
  }
}
static void do_cmp(u16 reg,u16 v,int w8){
  u32 r; P&=~(FC|FN|FZ);
  if(w8){ r=(reg&0xFF)-(v&0xFF); if(!((reg&0xFF)<(v&0xFF)))P|=FC; if(!(r&0xFF))P|=FZ; if(r&0x80)P|=FN; }
  else { r=reg-v; if(!(reg<v))P|=FC; if(!(r&0xFFFF))P|=FZ; if(r&0x8000)P|=FN; }
}
static u16 do_asl(u16 v){ if(M8){ P&=~FC; if(v&0x80)P|=FC; v=(v<<1)&0xFF; setNZ8(v);} else { P&=~FC; if(v&0x8000)P|=FC; v=(v<<1)&0xFFFF; setNZ16(v);} return v; }
static u16 do_lsr(u16 v){ if(M8){ P&=~FC; if(v&1)P|=FC; v=(v&0xFF)>>1; setNZ8(v);} else { P&=~FC; if(v&1)P|=FC; v>>=1; setNZ16(v);} return v; }
static u16 do_rol(u16 v){ int c=P&FC; if(M8){ P&=~FC; if(v&0x80)P|=FC; v=((v<<1)|c)&0xFF; setNZ8(v);} else { P&=~FC; if(v&0x8000)P|=FC; v=((v<<1)|c)&0xFFFF; setNZ16(v);} return v; }
static u16 do_ror(u16 v){ int c=P&FC; if(M8){ P&=~FC; if(v&1)P|=FC; v=((v&0xFF)>>1)|(c<<7); setNZ8(v);} else { P&=~FC; if(v&1)P|=FC; v=(v>>1)|(c<<15); setNZ16(v);} return v; }
static void branch(int cond){ int8_t o=(int8_t)fetch8(); if(cond){ PC+=o; } }
int cpu_step(void){
  if(waiting||stopped) return 0;
  { extern long bp_addr; if(bp_addr>=0 && (((u32)PB<<16)|PC)==(u32)bp_addr){ extern long frame; static int bn=0; if(bn<4000){ bn++; fprintf(stderr,"BP f%ld %02X:%04X A=%04X X=%04X Y=%04X dp00-0A:",frame,PB,PC,A,X,Y); for(int q=0;q<11;q++) fprintf(stderr," %02X",wram[(D+q)&0x1FFF]); fprintf(stderr,"\n"); if(getenv("BPJ")){ u32 ra=wram[(S+1)&0x1FFF]|(wram[(S+2)&0x1FFF]<<8); u8 rb=wram[(S+3)&0x1FFF]; fprintf(stderr,"HDR ret=%02X:%04X bytes:",rb,ra); for(int q=1;q<=10;q++){ extern u8 read8(u32); dataread=0; fprintf(stderr," %02X",read8(((u32)rb<<16)|((ra+q)&0xFFFF))); } fprintf(stderr,"\n"); } } } }
  { extern long frame; if(PB==0 && PC==0xC3C4 && getenv("DEC")){ static int dn=0; u32 da=wram[0x25]|(wram[0x26]<<8); u8 db=wram[0x27]; u32 sz=wram[0x23]|(wram[0x24]<<8); u32 base=(db==0x7F)?0x10000+da:(db==0x7E?da:0x1FFFF); if(base+sz<=0x20000 && dn<200){ char fn[64]; sprintf(fn,"dec_%03d_f%ld_%02X%04X.bin",dn++,frame,db,da); FILE*f=fopen(fn,"wb"); fwrite(wram+base,1,sz,f); fclose(f); fprintf(stderr,"DEC %s size=%X\n",fn,sz);} } }
  u8 op=fetch8(); cycles+=3; u32 ea; u8 b; u16 w; u16 v;
  int cc=op&3, bbb=(op>>2)&7, aaa=op>>5;
  /* group1: cc=1 or cc=3 (except specific), or (dp) forms */
  int isg1=0;
  if(cc==1) isg1=1;
  else if(cc==3 && bbb!=2 && bbb!=6 && !(bbb==3 && 0) ) isg1=1;
  if(cc==3 && (op==0x0B||op==0x2B||op==0x4B||op==0x6B||op==0x8B||op==0xAB||op==0xCB||op==0xEB||op==0x1B||op==0x3B||op==0x5B||op==0x7B||op==0x9B||op==0xBB||op==0xDB||op==0xFB||op==0x13||op==0x33)) isg1=(op==0x13||op==0x33)?1:0;
  if(cc==3 && bbb==3 && (op==0x6B||op==0x4B||op==0x0B||op==0x2B||op==0x8B||op==0xAB||op==0xCB||op==0xEB)) isg1=0;
  if(cc==2 && bbb==4 && (aaa!=4 && aaa!=5)) isg1=1; /* 12,32,52,72,D2,F2 and 92? */
  if(op==0x92||op==0xB2) isg1=1;
  if(op==0x89) isg1=0;
  if(op==0x12||op==0x32||op==0x52||op==0x72||op==0xD2||op==0xF2) isg1=1;
  if(cc==2 && bbb==4 && !(op==0x12||op==0x32||op==0x52||op==0x72||op==0x92||op==0xB2||op==0xD2||op==0xF2)) isg1=0;
  if(isg1){
    int imm=(cc==1&&bbb==2);
    /* ops by aaa: 0 ORA 1 AND 2 EOR 3 ADC 4 STA 5 LDA 6 CMP 7 SBC */
    if(aaa==4){ if(imm) return 1; ea=g1addr(bbb,cc,op); wrm(ea,A); return 0; }
    if(imm){ if(M8) v=fetch8(); else v=fetch16(); } else { ea=g1addr(bbb,cc,op); v=rdm(ea); }
    switch(aaa){
      case 0: if(M8){ A=(A&0xFF00)|((A|v)&0xFF); setNZ8(A&0xFF);} else { A|=v; setNZ16(A);} break;
      case 1: if(M8){ A=(A&0xFF00)|((A&v)&0xFF); setNZ8(A&0xFF);} else { A&=v; setNZ16(A);} break;
      case 2: if(M8){ A=(A&0xFF00)|((A^v)&0xFF); setNZ8(A&0xFF);} else { A^=v; setNZ16(A);} break;
      case 3: do_adc(v); break;
      case 5: if(M8){ A=(A&0xFF00)|(v&0xFF); setNZ8(v&0xFF);} else { A=v; setNZ16(v);} break;
      case 6: do_cmp(A,v,M8); break;
      case 7: do_sbc(v); break;
    }
    return 0;
  }
  switch(op){
  /* ---- shifts/inc/dec RMW ---- */
  case 0x0A: A=(M8?((A&0xFF00)|(do_asl(A&0xFF)&0xFF)):do_asl(A)); break;
  case 0x4A: A=(M8?((A&0xFF00)|(do_lsr(A&0xFF)&0xFF)):do_lsr(A)); break;
  case 0x2A: A=(M8?((A&0xFF00)|(do_rol(A&0xFF)&0xFF)):do_rol(A)); break;
  case 0x6A: A=(M8?((A&0xFF00)|(do_ror(A&0xFF)&0xFF)):do_ror(A)); break;
  case 0x1A: if(M8){ A=(A&0xFF00)|((A+1)&0xFF); setNZ8(A&0xFF);} else { A++; setNZ16(A);} break;
  case 0x3A: if(M8){ A=(A&0xFF00)|((A-1)&0xFF); setNZ8(A&0xFF);} else { A--; setNZ16(A);} break;
#define RMW(opc,mode,fn) case opc: ea=mode; v=rdm(ea); v=fn(v); wrm(ea,v); break;
  case 0x06: ea=ea_dp(fetch8()); v=rdm(ea); v=do_asl(v); wrm(ea,v); break;
  case 0x16: ea=ea_dpx(fetch8()); v=rdm(ea); v=do_asl(v); wrm(ea,v); break;
  case 0x0E: ea=ea_abs(fetch16()); v=rdm(ea); v=do_asl(v); wrm(ea,v); break;
  case 0x1E: ea=ea_absx(fetch16())&0xFFFFFF; v=rdm(ea); v=do_asl(v); wrm(ea,v); break;
  case 0x46: ea=ea_dp(fetch8()); v=rdm(ea); v=do_lsr(v); wrm(ea,v); break;
  case 0x56: ea=ea_dpx(fetch8()); v=rdm(ea); v=do_lsr(v); wrm(ea,v); break;
  case 0x4E: ea=ea_abs(fetch16()); v=rdm(ea); v=do_lsr(v); wrm(ea,v); break;
  case 0x5E: ea=ea_absx(fetch16())&0xFFFFFF; v=rdm(ea); v=do_lsr(v); wrm(ea,v); break;
  case 0x26: ea=ea_dp(fetch8()); v=rdm(ea); v=do_rol(v); wrm(ea,v); break;
  case 0x36: ea=ea_dpx(fetch8()); v=rdm(ea); v=do_rol(v); wrm(ea,v); break;
  case 0x2E: ea=ea_abs(fetch16()); v=rdm(ea); v=do_rol(v); wrm(ea,v); break;
  case 0x3E: ea=ea_absx(fetch16())&0xFFFFFF; v=rdm(ea); v=do_rol(v); wrm(ea,v); break;
  case 0x66: ea=ea_dp(fetch8()); v=rdm(ea); v=do_ror(v); wrm(ea,v); break;
  case 0x76: ea=ea_dpx(fetch8()); v=rdm(ea); v=do_ror(v); wrm(ea,v); break;
  case 0x6E: ea=ea_abs(fetch16()); v=rdm(ea); v=do_ror(v); wrm(ea,v); break;
  case 0x7E: ea=ea_absx(fetch16())&0xFFFFFF; v=rdm(ea); v=do_ror(v); wrm(ea,v); break;
  case 0xE6: ea=ea_dp(fetch8()); v=rdm(ea)+1; wrm(ea,v); setNZm(M8?(v&0xFF):v); break;
  case 0xF6: ea=ea_dpx(fetch8()); v=rdm(ea)+1; wrm(ea,v); setNZm(M8?(v&0xFF):v); break;
  case 0xEE: ea=ea_abs(fetch16()); v=rdm(ea)+1; wrm(ea,v); setNZm(M8?(v&0xFF):v); break;
  case 0xFE: ea=ea_absx(fetch16())&0xFFFFFF; v=rdm(ea)+1; wrm(ea,v); setNZm(M8?(v&0xFF):v); break;
  case 0xC6: ea=ea_dp(fetch8()); v=rdm(ea)-1; wrm(ea,v); setNZm(M8?(v&0xFF):v); break;
  case 0xD6: ea=ea_dpx(fetch8()); v=rdm(ea)-1; wrm(ea,v); setNZm(M8?(v&0xFF):v); break;
  case 0xCE: ea=ea_abs(fetch16()); v=rdm(ea)-1; wrm(ea,v); setNZm(M8?(v&0xFF):v); break;
  case 0xDE: ea=ea_absx(fetch16())&0xFFFFFF; v=rdm(ea)-1; wrm(ea,v); setNZm(M8?(v&0xFF):v); break;
  /* TSB / TRB */
  case 0x04: ea=ea_dp(fetch8()); v=rdm(ea); P&=~FZ; if(!(v&A&(M8?0xFF:0xFFFF)))P|=FZ; wrm(ea,v|A); break;
  case 0x0C: ea=ea_abs(fetch16()); v=rdm(ea); P&=~FZ; if(!(v&A&(M8?0xFF:0xFFFF)))P|=FZ; wrm(ea,v|A); break;
  case 0x14: ea=ea_dp(fetch8()); v=rdm(ea); P&=~FZ; if(!(v&A&(M8?0xFF:0xFFFF)))P|=FZ; wrm(ea,v&~A); break;
  case 0x1C: ea=ea_abs(fetch16()); v=rdm(ea); P&=~FZ; if(!(v&A&(M8?0xFF:0xFFFF)))P|=FZ; wrm(ea,v&~A); break;
  /* BIT */
  case 0x89: if(M8){ v=fetch8(); P&=~FZ; if(!(v&A&0xFF))P|=FZ; } else { v=fetch16(); P&=~FZ; if(!(v&A))P|=FZ; } break;
  case 0x24: case 0x34: case 0x2C: case 0x3C:
    ea = op==0x24?ea_dp(fetch8()): op==0x34?ea_dpx(fetch8()): op==0x2C?ea_abs(fetch16()): (ea_absx(fetch16())&0xFFFFFF);
    v=rdm(ea); P&=~(FN|FV|FZ);
    if(M8){ if(v&0x80)P|=FN; if(v&0x40)P|=FV; if(!(v&A&0xFF))P|=FZ; }
    else { if(v&0x8000)P|=FN; if(v&0x4000)P|=FV; if(!(v&A))P|=FZ; }
    break;
  /* branches */
  case 0x10: branch(!(P&FN)); break; case 0x30: branch(P&FN); break;
  case 0x50: branch(!(P&FV)); break; case 0x70: branch(P&FV); break;
  case 0x90: branch(!(P&FC)); break; case 0xB0: branch(P&FC); break;
  case 0xD0: branch(!(P&FZ)); break; case 0xF0: branch(P&FZ); break;
  case 0x80: branch(1); break;
  case 0x82: w=fetch16(); PC+=(int16_t)w; break;
  /* flags */
  case 0x18: P&=~FC; break; case 0x38: P|=FC; break;
  case 0x58: P&=~FI; break; case 0x78: P|=FI; break;
  case 0xB8: P&=~FV; break; case 0xD8: P&=~FD; break; case 0xF8: P|=FD; break;
  case 0xC2: b=fetch8(); setP(P&~b); if(E)P|=0x30; break;
  case 0xE2: b=fetch8(); setP(P|b); break;
  case 0xFB: { u8 c=P&FC; P=(P&~FC)|E; E=c; if(E){ P|=0x30; S=0x100|(S&0xFF); X&=0xFF; Y&=0xFF; } } break;
  /* cmp x/y */
  case 0xE0: v=X8?fetch8():fetch16(); do_cmp(X,v,X8); break;
  case 0xE4: ea=ea_dp(fetch8()); v=rdx(ea); do_cmp(X,v,X8); break;
  case 0xEC: ea=ea_abs(fetch16()); v=rdx(ea); do_cmp(X,v,X8); break;
  case 0xC0: v=X8?fetch8():fetch16(); do_cmp(Y,v,X8); break;
  case 0xC4: ea=ea_dp(fetch8()); v=rdx(ea); do_cmp(Y,v,X8); break;
  case 0xCC: ea=ea_abs(fetch16()); v=rdx(ea); do_cmp(Y,v,X8); break;
  /* inc/dec x y */
  case 0xE8: if(X8){ X=(X+1)&0xFF; setNZ8(X);} else { X++; setNZ16(X);} break;
  case 0xC8: if(X8){ Y=(Y+1)&0xFF; setNZ8(Y);} else { Y++; setNZ16(Y);} break;
  case 0xCA: if(X8){ X=(X-1)&0xFF; setNZ8(X);} else { X--; setNZ16(X);} break;
  case 0x88: if(X8){ Y=(Y-1)&0xFF; setNZ8(Y);} else { Y--; setNZ16(Y);} break;
  /* jumps */
  case 0x4C: PC=fetch16(); break;
  case 0x5C: { u32 a=fetch24(); PC=a&0xFFFF; PB=a>>16; } break;
  case 0x6C: w=fetch16(); PC=read16b0(w); break;
  case 0x7C: w=fetch16(); { u32 a=((u32)PB<<16)|((w+xv())&0xFFFF); dataread=1; PC=read8(a)|(read8(((u32)PB<<16)|((a+1)&0xFFFF))<<8); } break;
  case 0xDC: w=fetch16(); dataread=1; { u32 a=w; PC=read8(a)|(read8((a+1)&0xFFFF)<<8); PB=read8((a+2)&0xFFFF); } break;
  case 0x20: w=fetch16(); push16(PC-1); PC=w; break;
  case 0xFC: w=fetch16(); push16(PC-1); { u32 a=((u32)PB<<16)|((w+xv())&0xFFFF); dataread=1; PC=read8(a)|(read8(((u32)PB<<16)|((a+1)&0xFFFF))<<8); } break;
  case 0x22: { u32 a=fetch24(); push8(PB); push16(PC-1); PC=a&0xFFFF; PB=a>>16; } break;
  case 0x60: PC=pull16()+1; break;
  case 0x6B: PC=pull16()+1; PB=pull8(); break;
  case 0x40: if(E){ setP(pull8()); PC=pull16(); } else { setP(pull8()); PC=pull16(); PB=pull8(); } break;
  case 0x00: b=fetch8(); interrupt(0xFFE6,0xFFFE,1); break;
  case 0x02: b=fetch8(); interrupt(0xFFE4,0xFFF4,0); break;
  /* loads x/y */
  case 0xA2: v=X8?fetch8():fetch16(); X=v; setNZx(X); break;
  case 0xA6: ea=ea_dp(fetch8()); X=rdx(ea); setNZx(X); break;
  case 0xB6: ea=ea_dpy(fetch8()); X=rdx(ea); setNZx(X); break;
  case 0xAE: ea=ea_abs(fetch16()); X=rdx(ea); setNZx(X); break;
  case 0xBE: ea=ea_absy(fetch16())&0xFFFFFF; X=rdx(ea); setNZx(X); break;
  case 0xA0: v=X8?fetch8():fetch16(); Y=v; setNZx(Y); break;
  case 0xA4: ea=ea_dp(fetch8()); Y=rdx(ea); setNZx(Y); break;
  case 0xB4: ea=ea_dpx(fetch8()); Y=rdx(ea); setNZx(Y); break;
  case 0xAC: ea=ea_abs(fetch16()); Y=rdx(ea); setNZx(Y); break;
  case 0xBC: ea=ea_absx(fetch16())&0xFFFFFF; Y=rdx(ea); setNZx(Y); break;
  /* stores x/y/z */
  case 0x86: ea=ea_dp(fetch8()); wrx(ea,X); break;
  case 0x96: ea=ea_dpy(fetch8()); wrx(ea,X); break;
  case 0x8E: ea=ea_abs(fetch16()); wrx(ea,X); break;
  case 0x84: ea=ea_dp(fetch8()); wrx(ea,Y); break;
  case 0x94: ea=ea_dpx(fetch8()); wrx(ea,Y); break;
  case 0x8C: ea=ea_abs(fetch16()); wrx(ea,Y); break;
  case 0x64: ea=ea_dp(fetch8()); wrm(ea,0); break;
  case 0x74: ea=ea_dpx(fetch8()); wrm(ea,0); break;
  case 0x9C: ea=ea_abs(fetch16()); wrm(ea,0); break;
  case 0x9E: ea=ea_absx(fetch16())&0xFFFFFF; wrm(ea,0); break;
  /* block move */
  case 0x54: case 0x44: { u8 dst=fetch8(), src=fetch8(); DB=dst; { extern long mvlo,mvhi; if(mvlo>=0 && dst==0 && Y>=mvlo && Y<=mvhi){ extern long frame; static int mn=0; if(mn<3000000){mn++; fprintf(stderr,"MV f%ld src=%02X:%04X dst=%02X:%04X cnt=%04X\n",frame,src,X,dst,Y,A);} } } 
      dataread=1; write8(((u32)dst<<16)|Y, read8(((u32)src<<16)|X));
      if(op==0x54){ X++; Y++; } else { X--; Y--; } if(X8){X&=0xFF;Y&=0xFF;}
      A--; if(A!=0xFFFF) PC-=3; } break;
  case 0xEA: break;
  case 0x42: fetch8(); break;
  /* push/pull */
  case 0x48: if(M8) push8(A); else push16(A); break;
  case 0x08: push8(P); break;
  case 0xDA: if(X8) push8(X); else push16(X); break;
  case 0x5A: if(X8) push8(Y); else push16(Y); break;
  case 0x68: if(M8){ A=(A&0xFF00)|pull8(); setNZ8(A&0xFF);} else { A=pull16(); setNZ16(A);} break;
  case 0x28: setP(pull8()); break;
  case 0xFA: if(X8){ X=pull8(); setNZ8(X);} else { X=pull16(); setNZ16(X);} break;
  case 0x7A: if(X8){ Y=pull8(); setNZ8(Y);} else { Y=pull16(); setNZ16(Y);} break;
  case 0x8B: push8(DB); break; case 0x0B: push16(D); break; case 0x4B: push8(PB); break;
  case 0xAB: DB=pull8(); setNZ8(DB); break;
  case 0x2B: D=pull16(); setNZ16(D); break;
  case 0xF4: w=fetch16(); push16(w); break;
  case 0xD4: ea=ea_dp(fetch8()); w=read16b0(ea); push16(w); break;
  case 0x62: w=fetch16(); push16(PC+(int16_t)w); break;
  /* transfers */
  case 0xAA: if(X8){ X=A&0xFF; setNZ8(X);} else { X=A; setNZ16(X);} break;
  case 0xA8: if(X8){ Y=A&0xFF; setNZ8(Y);} else { Y=A; setNZ16(Y);} break;
  case 0x8A: if(M8){ A=(A&0xFF00)|(X&0xFF); setNZ8(A&0xFF);} else { A=X; setNZ16(A);} break;
  case 0x98: if(M8){ A=(A&0xFF00)|(Y&0xFF); setNZ8(A&0xFF);} else { A=Y; setNZ16(A);} break;
  case 0x9B: if(X8){ Y=X&0xFF; setNZ8(Y);} else { Y=X; setNZ16(Y);} break;
  case 0xBB: if(X8){ X=Y&0xFF; setNZ8(X);} else { X=Y; setNZ16(X);} break;
  case 0x5B: D=A; setNZ16(D); break;
  case 0x7B: A=D; setNZ16(A); break;
  case 0x1B: S=A; if(E) S=0x100|(S&0xFF); break;
  case 0x3B: A=S; setNZ16(A); break;
  case 0xBA: if(X8){ X=S&0xFF; setNZ8(X);} else { X=S; setNZ16(X);} break;
  case 0x9A: if(E) S=0x100|(X&0xFF); else S=X; break;
  case 0xEB: A=((A&0xFF)<<8)|(A>>8); setNZ8(A&0xFF); break;
  case 0xCB: waiting=1; break;
  case 0xDB: stopped=1; break;
  default: fprintf(stderr,"unimpl op %02X at %02X:%04X\n",op,PB,(u16)(PC-1)); exit(1);
  }
  return 0;
}
