import sys; sys.path.insert(0,'/home/claude/emu')
from textlib import *
def parse(o):
    rows=[];p=o
    while True:
        n=d[p]
        if n==0: p+=1; break
        if n>40 or p+1+2*n>len(d): return None
        rows.append((p,[(p+1+2*k,d[p+1+2*k],d[p+2+2*k]) for k in range(n)])); p+=1+2*n
        if len(rows)>40: return None
    return rows,p
def ok(rows):
    if len(rows)<3: return False
    first=rows[0][1]; last=rows[-1][1]
    if first[0][1]!=0x04 or first[-1][1]!=0x06: return False
    if last[0][1]!=0x09 or last[-1][1]!=0x0B: return False
    for p,r in rows[1:-1]:
        if r[0][1]!=0x07 or r[-1][1]!=0x08: return False
    return True
def find():
    res=[];seen=set()
    for o in range(len(d)-8):
        n=d[o]
        if 4<=n<=40 and d[o+1]==0x04 and 0x20<=d[o+2]<=0x3F:
            r=parse(o)
            if r and ok(r[0]):
                res.append((o,r[0],r[1]))
    return res
GL={0x01:' ',0x3E:'`',0x3F:'`'}
def cell(t,a):
    if t<0x10 and t!=1: return '#'
    if t in GL: return GL[t]
    return T.get(t,'?')
if __name__=='__main__':
    ts=find(); print(len(ts))
    import json
    json.dump([[o,[[p,[(q,t,a) for q,t,a in r]] for p,r in rows],end] for o,rows,end in ts],open('templates.json','w'))
    for o,rows,end in ts:
        print(f"=== {o:X}..{end:X} rows={len(rows)} width={len(rows[0][1])}")
        for ri,(p,r) in enumerate(rows):
            s=''.join(cell(t,a) for q,t,a in r)
            if any(t not in (1,) and t>=0x10 for q,t,a in r) : print(f"  r{ri:2d} @{p:X} |{s}|")
