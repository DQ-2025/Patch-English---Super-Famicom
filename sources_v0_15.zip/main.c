#include "cpu.h"
u16 vram[0x8000]; u8 oam[544]; u16 cgram[256];
static u16 vaddr; static u8 vmain; static u16 vread_latch;
static u16 cgaddr; static int cgflip; static u8 cglatch;
static u16 oamidx; static u8 oamlatch;
static u8 bgmode, bgsc[4], bgnba[2]; static u16 bghofs[4], bgvofs[4]; static u8 ofslatch, hofslatch;
static u8 tm, ts, inidisp, objsel;
static u8 nmitimen, rdnmi, timeup, hvbjoy;
static u16 htime, vtime;
static u32 wmadd; static u16 mulres, divres;
static u8 mul_a, mul_b; 
static u8 dmareg[8][16]; static u8 dmaen;
static u8 apuin[4]={0xAA,0xBB,0,0}; static u8 apuout[4]; static int ipl_mode=0, ipl_idx=0;
static u16 joy1=0; static u16 joylatch; static int joybit;
long vwlo=-1,vwhi=-1; long frame=0; long wwatch=-1; long bp_addr=-1; long watch_lo=-1, watch_hi=-2; static int line=0;
static FILE *dmalog;
static u16 divd; 
static int vinc(void){ int m=vmain&3; return m==0?1:(m==1?32:128); }
static u16 vmap(u16 a){ int m=(vmain>>2)&3; if(!m) return a&0x7FFF;
  if(m==1) return (a&0xFF00)|((a&0x1F)<<3)|((a>>5)&7);
  if(m==2) return (a&0xFE00)|((a&0x3F)<<3)|((a>>6)&7);
  return (a&0xFC00)|((a&0x7F)<<3)|((a>>7)&7); }
u8 io_read(u16 a){
  if(a==0x2180){ u8 v=wram[wmadd&0x1FFFF]; wmadd++; return v; }
  if(a>=0x2140&&a<0x2144){ if(ipl_mode==0){ static const u8 w[4]={0xAA,0xBB,0,0}; return w[a&3]; } return apuin[a&3]; }
  switch(a){
    case 0x2139: { u8 v=vread_latch&0xFF; if(!(vmain&0x80)){ vread_latch=vram[vmap(vaddr)&0x7FFF]; vaddr+=vinc(); } return v; }
    case 0x213A: { u8 v=vread_latch>>8; if(vmain&0x80){ vread_latch=vram[vmap(vaddr)&0x7FFF]; vaddr+=vinc(); } return v; }
    case 0x213E: return 1;
    case 0x213F: return 3;
    case 0x4210: { u8 v=(rdnmi&0x80)|0x02; rdnmi&=0x7F; return v; }
    case 0x4211: { u8 v=timeup; timeup=0; return v; }
    case 0x4212: return hvbjoy;
    case 0x4214: return divres&0xFF; case 0x4215: return divres>>8;
    case 0x4216: return mulres&0xFF; case 0x4217: return mulres>>8;
    case 0x4218: return joy1&0xFF; case 0x4219: return joy1>>8;
    case 0x4016: { u8 v=(joybit<16)?((joylatch>>(15-joybit))&1):1; if(joybit<16) joybit++; return v; }
    case 0x4017: return 0x1C;
  }
  if(a>=0x4300&&a<0x4380) return dmareg[(a>>4)&7][a&15];
  { extern unsigned char wr7f[0x10000],wrlow[0x2000]; FILE*q=fopen("wrmap.bin","wb"); fwrite(wrlow,1,0x2000,q); fwrite(wr7f,1,0x10000,q); fclose(q);} return 0;
}
static void ppu_write(u16 a,u8 v){
  switch(a){
    case 0x2100: inidisp=v; break;
    case 0x2101: objsel=v; break;
    case 0x2102: oamidx=((oamidx&0x200)|(v<<1))&0x3FF; break;
    case 0x2103: oamidx=((oamidx&0x1FE)|((v&1)<<9))&0x3FF; break;
    case 0x2104: if(oamidx>=512){ oam[512+(oamidx&31)]=v; oamidx=(oamidx+1)&0x3FF; }
      else if(!(oamidx&1)){ oamlatch=v; oamidx++; } else { oam[oamidx-1]=oamlatch; oam[oamidx]=v; oamidx=(oamidx+1)&0x3FF; } break;
    case 0x2105: bgmode=v; break;
    case 0x2107: case 0x2108: case 0x2109: case 0x210A: bgsc[a-0x2107]=v; break;
    case 0x210B: bgnba[0]=v; break; case 0x210C: bgnba[1]=v; break;
    case 0x210D: case 0x210F: case 0x2111: case 0x2113: { int n=(a-0x210D)/2; bghofs[n]=((v<<8)|(ofslatch&~7)|(hofslatch&7))&0x3FF; ofslatch=v; hofslatch=v; } break;
    case 0x210E: case 0x2110: case 0x2112: case 0x2114: { int n=(a-0x210E)/2; bgvofs[n]=((v<<8)|ofslatch)&0x3FF; ofslatch=v; } break;
    case 0x2115: vmain=v; break;
    case 0x2116: vaddr=(vaddr&0xFF00)|v; vread_latch=vram[vmap(vaddr)&0x7FFF]; break;
    case 0x2117: vaddr=(vaddr&0xFF)|(v<<8); vread_latch=vram[vmap(vaddr)&0x7FFF]; break;
    case 0x2118: { { extern long vwlo,vwhi; extern u8 PB; extern u16 PC; if(vwlo>=0 && vaddr>=vwlo && vaddr<=vwhi){ static int vn=0; if(vn<20000000){vn++; fprintf(stderr,"VW f%ld vaddr=%04X lo=%02X PC=%02X:%04X\n",frame,vaddr,v,PB,(u16)(PC-1));} } } { extern u8 PB; extern u16 PC; static int nn=0; static long hist[65536]; static int hinit=0; if(getenv("V18")){ hist[(u16)(PC-1)]++; if(hist[(u16)(PC-1)]==1 && nn<60){ nn++; fprintf(stderr,"V2118 f%ld vaddr=%04X val=%02X PC=%02X:%04X\n",frame,vaddr,v,PB,(u16)(PC-1)); } } } u16 ad=vmap(vaddr)&0x7FFF; vram[ad]=(vram[ad]&0xFF00)|v; if(!(vmain&0x80)) vaddr+=vinc(); } break;
    case 0x2119: { u16 ad=vmap(vaddr)&0x7FFF; vram[ad]=(vram[ad]&0x00FF)|(v<<8); if(vmain&0x80) vaddr+=vinc(); } break;
    case 0x2121: cgaddr=v; cgflip=0; break;
    case 0x2122: if(!cgflip){ cglatch=v; cgflip=1; } else { cgram[cgaddr&255]=cglatch|((v&0x7F)<<8); cgaddr++; cgflip=0; } break;
    case 0x212C: tm=v; break; case 0x212D: ts=v; break;
    case 0x2180: wram[wmadd&0x1FFFF]=v; wmadd++; break;
    case 0x2181: wmadd=(wmadd&0x1FF00)|v; break;
    case 0x2182: wmadd=(wmadd&0x100FF)|(v<<8); break;
    case 0x2183: wmadd=(wmadd&0xFFFF)|((v&1)<<16); break;
  }
}
static void do_dma(void){
  static const int pat[8][4]={{0,0,0,0},{0,1,0,1},{0,0,0,0},{0,0,1,1},{0,1,2,3},{0,1,0,1},{0,0,0,0},{0,0,1,1}};
  static const int plen[8]={1,2,2,4,4,4,2,4};
  for(int ch=0;ch<8;ch++){ if(!(dmaen&(1<<ch))) continue;
    u8 *r=dmareg[ch]; u8 ctrl=r[0]; u8 dest=r[1];
    u32 src=r[2]|(r[3]<<8)|(r[4]<<16); u32 size=r[5]|(r[6]<<8); if(!size) size=0x10000;
    int dir=ctrl&0x80, fixed=ctrl&0x08, dec=ctrl&0x10, mode=ctrl&7;
    if(dmalog && !dir) fprintf(dmalog,"f%ld ch%d src=%06X size=%04X dest=21%02X mode=%d vaddr=%04X\n",frame,ch,src,size,dest,mode,vaddr);
    u32 i=0; int k=0;
    while(i<size){
      u16 d=0x2100+dest+pat[mode][k%plen[mode]];
      if(!dir){ dataread=1; u8 v=read8(src); if(d>=0x2100&&d<0x2200) ppu_write(d,v); else if(d>=0x2140&&d<0x2144) {} else write8(d,v); }
      else { u8 v=io_read(d); write8(src,v); }
      if(!fixed){ if(dec) src=(src&0xFF0000)|((src-1)&0xFFFF); else src=(src&0xFF0000)|((src+1)&0xFFFF); }
      i++; k++;
    }
    r[5]=r[6]=0; r[2]=src&0xFF; r[3]=(src>>8)&0xFF; cycles+=size/2;
  }
  dmaen=0;
}
void io_write(u16 a,u8 v){
  if(a>=0x2140&&a<0x2144){ int p=a&3; apuout[p]=v;
    if(p!=0){ if(ipl_mode!=0) apuin[p]=v; return; }
    if(ipl_mode==0){ if(v==0xCC){ ipl_mode=1; ipl_idx=0; apuin[0]=0xCC; apuin[1]=apuout[1]; } }
    else if(ipl_mode==1){ if(v==(u8)ipl_idx){ ipl_idx++; apuin[0]=v; } else { apuin[0]=v; if(apuout[1]==0) ipl_mode=2; else ipl_idx=0; } }
    else { if(v==0xFF){ ipl_mode=0; } else apuin[0]=v; }
    return; }
  if(a>=0x2100&&a<0x2200){ ppu_write(a,v); return; }
  if(a>=0x2180&&a<0x2184){ ppu_write(a,v); return; }
  if(a>=0x4300&&a<0x4380){ dmareg[(a>>4)&7][a&15]=v; return; }
  switch(a){
    case 0x4016: if(!(v&1)){ joylatch=joy1; joybit=0; } break;
    case 0x4200: nmitimen=v; break;
    case 0x4202: mul_a=v; break;
    case 0x4203: mul_b=v; mulres=mul_a*mul_b; break;
    case 0x4204: divd=(divd&0xFF00)|v; break; case 0x4205: divd=(divd&0xFF)|(v<<8); break;
    case 0x4206: if(v){ divres=divd/v; mulres=divd%v; } else { divres=0xFFFF; mulres=divd; } break;
    case 0x4207: htime=(htime&0x100)|v; break; case 0x4208: htime=(htime&0xFF)|((v&1)<<8); break;
    case 0x4209: vtime=(vtime&0x100)|v; break; case 0x420A: vtime=(vtime&0xFF)|((v&1)<<8); break;
    case 0x420B: dmaen=v; do_dma(); break;
    case 0x420C: break;
  }
}
/* ---------- rendering ---------- */
static u8 fb[256*224*3]; static u8 fbpri[256*224];
static void color(int idx,u8 *o){ u16 c=cgram[idx&255]; o[0]=(c&31)*255/31; o[1]=((c>>5)&31)*255/31; o[2]=((c>>10)&31)*255/31; }
static int bgbpp(int mode,int bg){
  static const int t[8][4]={{2,2,2,2},{4,4,2,0},{4,4,0,0},{8,4,0,0},{8,2,0,0},{4,2,0,0},{4,0,0,0},{8,0,0,0}};
  return t[mode&7][bg]; }
static int tilepix(u32 base,int tile,int x,int y,int bpp){
  int words=bpp*4; u32 a=(base+tile*words)&0x7FFF; int v=0;
  for(int p=0;p<bpp/2;p++){ u16 w=vram[(a+y+p*8)&0x7FFF]; int bit=7-x; v|=(((w>>bit)&1)|(((w>>(8+bit))&1)<<1))<<(p*2); }
  return v;
}
static void render_bg(int bg,int pri_wanted){
  int bpp=bgbpp(bgmode,bg); if(!bpp) return;
  u32 sc=(bgsc[bg]&0xFC)<<8; int sz=bgsc[bg]&3;
  u32 cb = (bg<2? (bg==0? (bgnba[0]&0xF):(bgnba[0]>>4)) : (bg==2? (bgnba[1]&0xF):(bgnba[1]>>4))) <<12;
  int big=0; /* tile size from BGMODE bit 4+bg */ big=(bgmode>>(4+bg))&1;
  int ts_=big?16:8;
  for(int y=0;y<224;y++) for(int x=0;x<256;x++){
    int px=(x+bghofs[bg])&0x3FF, py=(y+bgvofs[bg])&0x3FF;
    int tx=px/ts_, ty=py/ts_; int scx=0,scy=0;
    int mapw=(sz&1)?64:32, maph=(sz&2)?64:32;
    tx%=mapw; ty%=maph; 
    u32 addr=sc; if(tx>=32){ addr+=0x400; tx-=32; } if(ty>=32){ addr+=(sz==3?0x800:0x400); ty-=32; }
    u16 e=vram[(addr+ty*32+tx)&0x7FFF];
    int pri=(e>>13)&1; if(pri!=pri_wanted) continue;
    int tile=e&0x3FF, pal=(e>>10)&7, hf=e&0x4000, vf=e&0x8000;
    int ix=px%ts_, iy=py%ts_;
    if(hf) ix=ts_-1-ix; if(vf) iy=ts_-1-iy;
    int t=tile; if(big){ t+= (ix>=8?1:0) + (iy>=8?16:0); ix&=7; iy&=7; }
    int c=tilepix(cb,t,ix,iy,bpp); if(!c) continue;
    int idx;
    if(bpp==4) idx=pal*16+c; else if(bpp==2) idx=(bgmode==0?bg*32:0)+pal*4+c; else idx=c;
    color(idx,&fb[(y*256+x)*3]);
  }
}
static void render_obj(int prio){
  static const int sz[8][2]={{8,16},{8,32},{8,64},{16,32},{16,64},{32,64},{16,32},{16,32}};
  int s=objsel>>5; u32 nb=(objsel&7)<<13; u32 gap=((objsel>>3)&3)<<12;
  for(int i=127;i>=0;i--){
    int x=oam[i*4], y=oam[i*4+1], t=oam[i*4+2], at=oam[i*4+3];
    int hi=(oam[512+i/4]>>((i&3)*2))&3; if(hi&1) x-=256; int big=hi>>1;
    int p=(at>>4)&3; if(p!=prio) continue;
    int w=big?sz[s][1]:sz[s][0]; int h=w; if(s==6||s==7){ w=big?32:16; h=big?32:32; if(s==6){h=big?32:32;} }
    if(s==6){ w=big?32:16; h=32; } if(s==7){ w=big?32:16; h=big?32:32; }
    y=(y+1)&255;
    for(int yy=0;yy<h;yy++) for(int xx=0;xx<w;xx++){
      int sx=x+xx, sy=(y+yy)&255; if(sx<0||sx>=256||sy>=224) continue;
      int ix=(at&0x40)?w-1-xx:xx, iy=(at&0x80)?h-1-yy:yy;
      int tn=(t&0xF0)+(((t&15)+(ix/8))&15)+(iy/8)*16; if(t&0x100)tn+=0; 
      u32 base=(at&1)? nb+gap+0x1000 : nb;
      int c=tilepix(base,tn&0xFF,ix&7,iy&7,4); if(!c) continue;
      color(128+((at>>1)&7)*16+c,&fb[(sy*256+sx)*3]);
    }
  }
}
void render(void){
  memset(fb,0,sizeof fb);
  if(inidisp&0x80) return;
  u8 enable=tm; if(getenv("MASK")) enable&=(u8)strtol(getenv("MASK"),0,0);
  int m=bgmode&7;
  /* back-to-front painter order for modes 0/1/2 approximations */
  if(m<=1){ if(enable&4){render_bg(2,0);} if(enable&2){render_bg(1,0);} if(enable&1){render_bg(0,0);} 
            if(enable&16)render_obj(0); if(enable&16)render_obj(1);
            if(enable&4){render_bg(2,1);} if(enable&2){render_bg(1,1);} if(enable&1){render_bg(0,1);} if(enable&16){render_obj(2);render_obj(3);} }
  else { for(int b=3;b>=0;b--){ if(enable&(1<<b)){ render_bg(b,0);} } for(int b=3;b>=0;b--){ if(enable&(1<<b)){ render_bg(b,1);} } if(enable&16){render_obj(0);render_obj(1);render_obj(2);render_obj(3);} }
}
void shot(const char *fn){ render(); FILE *f=fopen(fn,"wb"); fprintf(f,"P6\n256 224\n255\n"); fwrite(fb,1,sizeof fb,f); fclose(f); }
/* ---------- frame loop ---------- */
static long nmi_at=-1;
static void run_line(int ln){
  long target=cycles+1364;
  long start=cycles;
  hvbjoy&=~0x40;
  while(cycles<target){
    if(waiting){ cycles=target; break; }
    long c0=cycles;
    if(irq_check_hook(0)){}
    cpu_step();
    if(nmi_at>=0 && cycles>=nmi_at){ nmi_at=-1; if(nmitimen&0x80) cpu_nmi(); }
    if(cycles-c0<3) cycles+=0;
    long el=cycles-start; hvbjoy=(hvbjoy&~0x40)|((el>=1100)?0x40:0);
  }
  cycles=target;
}
int irq_check_hook(int x){ return 0; }
void set_pad(u16 v){ joy1=v; }
void run_frame(void){
  for(line=0;line<262;line++){
    if(line==0){ hvbjoy&=~0x80; rdnmi&=~0x80; }
    if(line==225){ hvbjoy|=0x80; rdnmi|=0x80; hvbjoy|=1; 
       if(nmitimen&0x80) nmi_at=cycles+14; }
    if(line==228) hvbjoy&=~1;
    if((nmitimen&0x30)==0x20 && line==vtime){ timeup=0x80; cpu_irq(); }
    if((nmitimen&0x30)==0x10){ timeup=0x80; cpu_irq(); }
    if((nmitimen&0x30)==0x30 && line==vtime){ timeup=0x80; cpu_irq(); }
    if(waiting && !(nmitimen&0xB0)) {}
    run_line(line);
  }
  frame++;
}
void dump(const char *pre){ char fn[256]; FILE *f;
  sprintf(fn,"%s_vram.bin",pre); f=fopen(fn,"wb"); fwrite(vram,2,0x8000,f); fclose(f);
  sprintf(fn,"%s_wram.bin",pre); f=fopen(fn,"wb"); fwrite(wram,1,0x20000,f); fclose(f);
  sprintf(fn,"%s_cgram.bin",pre); f=fopen(fn,"wb"); fwrite(cgram,2,256,f); fclose(f);
  sprintf(fn,"%s_oam.bin",pre); f=fopen(fn,"wb"); fwrite(oam,1,544,f); fclose(f);
  sprintf(fn,"%s_regs.txt",pre); f=fopen(fn,"w"); fprintf(f,"bgmode=%02X sc=%02X %02X %02X %02X nba=%02X %02X tm=%02X objsel=%02X inidisp=%02X\n",bgmode,bgsc[0],bgsc[1],bgsc[2],bgsc[3],bgnba[0],bgnba[1],tm,objsel,inidisp); fclose(f);
}
static u16 parse_btn(const char *s){ u16 v=0; for(;*s;s++) switch(*s){
  case 'B':v|=0x8000;break; case 'Y':v|=0x4000;break; case 'S':v|=0x2000;break; case 'T':v|=0x1000;break;
  case 'U':v|=0x0800;break; case 'D':v|=0x0400;break; case 'L':v|=0x0200;break; case 'R':v|=0x0100;break;
  case 'A':v|=0x0080;break; case 'X':v|=0x0040;break; case 'l':v|=0x0020;break; case 'r':v|=0x0010;break; } return v; }
int main(int argc,char **argv){
  FILE *f=fopen(argv[1],"rb"); fseek(f,0,SEEK_END); romsize=ftell(f); fseek(f,0,SEEK_SET); rom=malloc(romsize); fread(rom,1,romsize,f); fclose(f);
  romtrace=calloc(romsize,1); if(getenv("WF1")){ extern long wf1,wf2; wf1=atol(getenv("WF1")); wf2=atol(getenv("WF2"));} if(getenv("VWLO")){ vwlo=strtol(getenv("VWLO"),0,16); vwhi=strtol(getenv("VWHI"),0,16);} if(getenv("MVLO")){ extern long mvlo,mvhi; mvlo=strtol(getenv("MVLO"),0,16); mvhi=strtol(getenv("MVHI"),0,16);} if(getenv("WRLO")){ extern long wrlo,wrhi; extern int wrval; wrlo=strtol(getenv("WRLO"),0,16); wrhi=strtol(getenv("WRHI"),0,16); wrval=getenv("WRVAL")?strtol(getenv("WRVAL"),0,16):-1;} if(getenv("BP")) bp_addr=strtol(getenv("BP"),0,16); if(getenv("WW")) wwatch=strtol(getenv("WW"),0,16); if(getenv("WLO")){ watch_lo=strtol(getenv("WLO"),0,16); watch_hi=strtol(getenv("WHI"),0,16);} 
  dmalog=fopen("dma.log","w");
  if(getenv("WRAMFILL")) memset(wram,(int)strtol(getenv("WRAMFILL"),0,16),sizeof wram);
  cpu_reset();
  FILE *sc=fopen(argv[2],"r"); char cmd[64],arg[256],arg2[64];
  while(fscanf(sc,"%63s",cmd)==1){
    if(!strcmp(cmd,"run")){ int n; fscanf(sc,"%d",&n); while(n--){ run_frame(); } }
    else if(!strcmp(cmd,"pad")){ fscanf(sc,"%255s",arg); joy1=(!strcmp(arg,"-"))?0:parse_btn(arg); }
    else if(!strcmp(cmd,"tap")){ int n; fscanf(sc,"%255s %d",arg,&n); joy1=parse_btn(arg); for(int i=0;i<3;i++) run_frame(); joy1=0; for(int i=0;i<n;i++) run_frame(); }
    else if(!strcmp(cmd,"shot")){ fscanf(sc,"%255s",arg); shot(arg); }
    else if(!strcmp(cmd,"dump")){ fscanf(sc,"%255s",arg); dump(arg); }
    else if(!strcmp(cmd,"trace")){ int n; fscanf(sc,"%d",&n); tracing=n; }
    else if(!strcmp(cmd,"tracedump")){ fscanf(sc,"%255s",arg); FILE *o=fopen(arg,"wb"); fwrite(romtrace,1,romsize,o); fclose(o); memset(romtrace,0,romsize); }
    else if(!strcmp(cmd,"state")){ fprintf(stderr,"frame %ld PB:PC=%02X:%04X A=%04X X=%04X Y=%04X P=%02X E=%d S=%04X nmitimen=%02X inidisp=%02X\n",frame,PB,PC,A,X,Y,P,E,S,nmitimen,inidisp); }
  }
  return 0;
}
