d=open('/home/claude/emu/game.sfc','rb').read()
def off(b,a): return ((b&0x7f)*0x8000+(a&0x7fff))
def addr(o): return (o//0x8000, 0x8000+(o%0x8000))
HIRA="あいうえおかきくけこさしすせそたちつてとなにぬねのはひふへほまみむめもやゆよらりるれろわをん"
KATA="アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲン"
T={}
for i,c in enumerate(HIRA): T[0x10+i]=c
T[0x3E]='゛';T[0x3F]='゜'
for c,ch in zip(range(0x40,0x50),"っゃゅょ・‥ー!?。、:/※「▼"): T[c]=ch
for i,c in enumerate(KATA): T[0x50+i]=c
T[0x7E]='α';T[0x7F]='β'
for c,ch in zip(range(0x80,0x89),"ッャュョァィゥェォ"): T[c]=ch
for i in range(10): T[0x90+i]=str(i)
for i in range(26): T[0x9A+i]=chr(65+i)
T[0x01]=' ';T[0x00]='□'
# voiced
VOI={}
def dk(base,mark):
    import unicodedata
    ch=T[base]; return unicodedata.normalize('NFC',ch+('\u3099' if mark==0x3E else '\u309A'))
ENT={}
tb=off(0,0xE8E0)
for c in range(0xB4,0xE6):
    m,u=d[tb+c*2],d[tb+c*2+1]
    T[c]=dk(m,u)
CTRL={0xE6:'<WAIT>',0xE7:'<N0>',0xE8:'<N1>',0xE9:'<ITEM>',0xEA:'<NAME2>',0xEB:'<NUM3A>',0xEC:'<NUM3B>',0xED:'<NUM2A>',0xEE:'<NUM2B>',0xEF:'<LTR1>',0xF0:'<LTR2>',0xFE:'\n',0xFF:'<END>'}
def isvalid(x): return x<0xE6 or 0xE6<=x<=0xF0 or x==0xFE or x==0xFF or 0xF5<=x<=0xFD
def dec(bs):
    s=''
    for x in bs:
        if x in CTRL: s+=CTRL[x]
        elif x in T: s+=T[x]
        else: s+=f"<{x:02X}>"
    return s
