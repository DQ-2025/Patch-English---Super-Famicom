import sys
def make(a,b,gap=6):
    a=bytes(a)+bytes(len(b)-len(a)); n=len(b); recs=[]; i=0
    while i<n:
        if a[i]==b[i]: i+=1; continue
        s=i; last=i; k=i
        while k<n and k-last<=gap:
            if a[k]!=b[k]: last=k
            k+=1
        recs.append((s,b[s:last+1])); i=last+1
    out=bytearray(b'PATCH')
    for off,data in recs:
        for p in range(0,len(data),0xFFFF):
            ch=data[p:p+0xFFFF]; o=off+p
            assert o!=0x454F46
            if len(ch)>=6 and len(set(ch))==1: out+=o.to_bytes(3,'big')+b'\0\0'+len(ch).to_bytes(2,'big')+ch[:1]
            else: out+=o.to_bytes(3,'big')+len(ch).to_bytes(2,'big')+ch
    return bytes(out+b'EOF')
if __name__=='__main__':
    import ips
    rom=open(sys.argv[1],'rb').read(); new=open(sys.argv[2],'rb').read()
    p=make(rom,new); open(sys.argv[3],'wb').write(p)
    assert bytes(ips.apply(rom,p))==new; print('ips ok',len(p))
