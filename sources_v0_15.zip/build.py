import json,sys,os,re,glob
sys.path.insert(0,'/home/claude/emu')
from glyphs import G,CODE,BOLD,bold_rows,tile_bytes
SRC='/home/claude/emu/game.sfc'
d=bytearray(open(SRC,'rb').read())
assert len(d)==0x100000
d+=bytes([0xFF])*0x100000
def lo(off): return (off//0x8000, 0x8000+off%0x8000)
def rom(bank,addr): return (bank&0x7F)*0x8000+(addr&0x7FFF)
# ---------- header ----------
d[0x7FD7]=0x0B
# ---------- font ----------
font=bytearray(open('/home/claude/emu/font_orig.bin','rb').read())
for ch,rows in G.items():
    t=CODE[ch]
    font[t*16:(t+1)*16]=tile_bytes(rows)
for ch in 'abcdefghijklmnopqrstuvwxyz':
    t=BOLD[ch]; font[t*16:(t+1)*16]=tile_bytes(bold_rows(G[ch]))
def rle(data):
    out=bytearray();i=0;n=len(data)
    while i<n:
        b=data[i];j=i
        while j<n and data[j]==b and j-i<255: j+=1
        run=j-i
        if run>=4 or (b==0xEA and run>=1 and False):
            out+=bytes([0xEA,run,b]);i=j
        elif b==0xEA:
            out+=bytes([0xEA,1,0xEA]);i+=1
        else:
            out.append(b);i+=1
    return bytes(out)
def unrle(s,size):
    out=bytearray();p=0
    while len(out)<size:
        b=s[p];p+=1
        if b==0xEA: n=s[p];v=s[p+1];p+=2;out+=bytes([v])*n
        else: out.append(b)
    return bytes(out[:size])
enc=rle(bytes(font)); assert unrle(enc,0x1000)==bytes(font)
FONT_OFF=0x100000
d[FONT_OFF:FONT_OFF+len(enc)]=enc
assert len(enc)<0x1800,len(enc)
pat=bytes([0x00,0x80,0x11,0xEA]);i=-1;n=0
while True:
    i=d.find(pat,i+1,0x100000)
    if i<0:break
    d[i+2]=0x20;n+=1
assert n==8
# ---------- font B (battle/title font, RLE marker FE, plane0 only) ----------
fontB=bytearray(open('/home/claude/emu/fontB_orig.bin','rb').read())
for ch,rows in G.items():
    t=CODE[ch]
    if t>=0xC0: continue
    tb=tile_bytes(rows)            # (bg,ink) pairs
    out=bytearray()
    for r in range(8): out+=bytes([tb[r*2+1],0])
    fontB[t*16:(t+1)*16]=out
for ch in 'abcdefghijklmnopqrstuvwxyz':
    t=BOLD[ch]; tb=tile_bytes(bold_rows(G[ch]))
    fontB[t*16:(t+1)*16]=b''.join(bytes([tb[r*2+1],0]) for r in range(8))
def rle_m(data,mk):
    out=bytearray();i=0;n=len(data)
    while i<n:
        b=data[i];j=i
        while j<n and data[j]==b and j-i<255: j+=1
        run=j-i
        if run>=4: out+=bytes([mk,run,b]);i=j
        elif b==mk: out+=bytes([mk,1,mk]);i+=1
        else: out.append(b);i+=1
    return bytes(out)
def unrle_m(s,size,mk):
    out=bytearray();p=0
    while len(out)<size:
        b=s[p];p+=1
        if b==mk: n=s[p];v=s[p+1];p+=2;out+=bytes([v])*n
        else: out.append(b)
    return bytes(out[:size])
encB=rle_m(bytes(fontB),0xFE); assert unrle_m(encB,0xC00,0xFE)==bytes(fontB)
FONTB_OFF=0x105000
d[FONTB_OFF:FONTB_OFF+len(encB)]=encB
assert len(encB)<0x3000
patB=bytes([0x64,0xD6,0x14,0xFE,0x00,0x0C]);i=-1;nb=0
while True:
    i=d.find(patB,i+1,0x100000)
    if i<0:break
    d[i:i+3]=bytes([0x00,0xD0,0x20]);nb+=1
assert nb==4,nb

# ---------- chapter title cards (graphics stream marker FD + tilemap rows) ----------
DIG={'1':["..#...",".##...","..#...","..#...","..#...","..#...",".###..","......"],
     '2':[".####.","#....#",".....#","...##.","..#...",".#....","######","......"],
     '3':[".####.","#....#",".....#","..###.",".....#","#....#",".####.","......"]}
CARDS=[((0x6449,0x6475),"Chapter 1","Hero of Lacroa"),
       ((0x64A1,0x64CD),"Chapter 2","The Legendary Giant"),
       ((0x64F9,0x6525),"Chapter 3","Argus Knights"),
       ((0x6551,0x657D),"Final Chapter","Knight of Light"),
       ((0x65A9,0x65D5),"Epilogue","")]
chars=[]
for _,l1,l2 in CARDS:
    for ch in l1+l2:
        if ch!=' ' and ch not in chars: chars.append(ch)
assert len(chars)<=68,len(chars)
cstream=bytearray(0x440)
cidx={}
for i,ch in enumerate(chars):
    cidx[ch]=i
    rows=G[ch] if ch in G else DIG[ch]
    tb=tile_bytes(rows)
    cstream[i*16:(i+1)*16]=b''.join(bytes([tb[r*2+1],0]) for r in range(8))
encC=rle_m(bytes(cstream),0xFD); assert unrle_m(encC,0x440,0xFD)==bytes(cstream)
CARD_OFF=0x106000; d[CARD_OFF:CARD_OFF+len(encC)]=encC
patC=bytes([0x72,0xFA,0x14,0xFD,0x40,0x04]); ci=d.find(patC,0,0x100000); assert ci==0x2584,hex(ci)
d[ci:ci+3]=bytes([0x00,0xE0,0x20])   # 20:E000 = rom 0x106000
def cardrow(addr,text):
    cells=[0x01]*20
    start=(20-len(text))//2
    for k,ch in enumerate(text):
        cells[start+k]=0x01 if ch==' ' else 0x10+cidx[ch]
    for k in range(20):
        d[addr+2+2*k]=cells[k]; d[addr+3+2*k]=0x3C
for (ra,rb),l1,l2 in CARDS:
    cardrow(ra,l1); cardrow(rb,l2)
# ---------- text ----------
segs=json.load(open('/home/claude/emu/segs.json'))
segstart={s for s,e in segs}
segend={s:e for s,e in segs}
VARS={'N0':0xE7,'N1':0xE8,'ITEM':0xE9,'MAG':0xEA,'N3A':0xEB,'N3B':0xEC,'N2A':0xED,'N2B':0xEE,'L1':0xEF,'L2':0xF0,'W':0xE6,'FA':0xFA,'FB':0xFB,'FC':0xFC,'FD':0xFD}
WIDTH=20; LINES=1000
def encode_raw(s):
    s=s.replace('...','…').replace('~','')
    out=bytearray(); linew=0
    i=0
    while i<len(s):
        if s[i]=='{':
            j=s.index('}',i); tok=s[i+1:j]; i=j+1
            if tok not in VARS and re.fullmatch(r'[0-9A-Fa-f]{2}',tok): VARS[tok]=int(tok,16)
            out.append(VARS[tok]); linew+=VWIDTH.get(tok,4) if tok!='W' else 0; continue
        if s[i]=='\\' and s[i+1]=='n':
            assert linew<=20,('line too long',s)
            if linew<20: out.append(0xFE)
            linew=0; i+=2; continue
        out.append(CODE[s[i]]); linew+=1; i+=1
    assert linew<=20,('line too long',s)
    out.append(0xFF); return bytes(out)
def encode_text(s):
    if s.startswith('='): return encode_raw(s[1:])
    s=s.replace('...','…').replace('~','').replace('’',"'").replace('“','"').replace('”','"')
    # tokenize into units (char or var) with display width
    bold=set()
    for m in re.finditer(r"(?:^|\\n|\{W\}|\\p)([A-Z][A-Za-z.' ]{1,22}):",s):
        bold.update(range(m.start(1),m.end(1)))
    units=[]; i=0
    while i<len(s):
        if s[i]=='{':
            j=s.index('}',i); tok=s[i+1:j]; i=j+1
            if tok not in VARS and re.fullmatch(r'[0-9A-Fa-f]{2}',tok): VARS[tok]=int(tok,16)
            units.append(('v',tok)); continue
        if s[i]=='\\':
            c=s[i+1]; i+=2; units.append(('n' if c=='n' else 'p',None)); continue
        units.append(('b' if (i in bold and s[i].isalpha()) else 'c',s[i])); i+=1
    # build lines respecting explicit \n,\p ; auto-wrap on spaces
    pages=[[]]; line=[]; 
    def width(l): return sum(1 if k in 'cb' else VWIDTH.get(v,4) for k,v in l)
    def flush():
        nonlocal line
        pages[-1].append(line); line=[]
        if len(pages[-1])==LINES: pages.append([])
    words=[];cur=[]
    for u in units:
        if u[0]=='c' and u[1]==' ': words.append(cur);cur=[];words.append([u]);
        elif u[0] in('n','p'): words.append(cur);cur=[];words.append([u])
        else: cur.append(u)
    words.append(cur)
    for w in words:
        if not w: continue
        if w[0][0]=='n': flush();continue
        if w[0][0]=='p':
            if line: flush()
            if pages[-1]: pages.append([])
            continue
        if w[0]==('c',' '):
            if line and width(line)<WIDTH: line.append(w[0])
            continue
        if width(line)+width(w)>WIDTH:
            while line and line[-1]==('c',' '): line.pop()
            flush()
        line.extend(w)
    while line and line[-1]==('c',' '): line.pop()
    if line: pages[-1].append(line)
    pages=[p for p in pages if p]
    out=bytearray()
    flat=[l for p in pages for l in p]
    for li,l in enumerate(flat):
        for k,v in l:
            out.append(CODE[v] if k=='c' else (BOLD[v] if k=='b' else VARS[v]))
        last=(li==len(flat)-1)
        if not last:
            if (li+1)%3==0: out.append(0xF1)
            elif width(l)<WIDTH: out.append(0xFE)
    out.append(0xFF)
    return bytes(out)
VWIDTH={'N0':4,'N1':4,'ITEM':8,'MAG':8,'N3A':3,'N3B':3,'N2A':2,'N2B':2,'L1':1,'L2':1,'W':0,'ED':10,'EE':10,'E7':4,'E8':4,'E9':8,'EA':8,'EB':3,'EC':3,'EF':1,'F0':1,'FA':1,'FB':1,'FC':1,'FD':1}
trans={}
for f in sorted(glob.glob('/home/claude/emu/tr/*.txt')):
    for ln in open(f,encoding='utf-8'):
        ln=ln.rstrip('\n')
        if not ln.strip() or ln.startswith('#'): continue
        a,t=ln.split('|',1); a=int(a,16)
        assert a in segstart,hex(a)
        trans[a]=t
# ---------- pack texts ----------
TEXT_BASE=0x108000
cur=TEXT_BASE; ptrs=[]
for a in sorted(trans):
    b=encode_text(trans[a])
    bank=cur//0x8000
    if (cur%0x8000)+len(b)>0x8000: cur=(bank+1)*0x8000
    d[cur:cur+len(b)]=b
    ob,oa=lo(a); nb,na=lo(cur)
    ptrs.append(((ob,oa),(nb,na)))
    cur+=len(b)
assert cur<0x200000
ptrs.sort()
TBL=0x102000
for i,((ob,oa),(nb,na)) in enumerate(ptrs):
    d[TBL+i*6:TBL+i*6+6]=bytes([oa&255,oa>>8,ob,na&255,na>>8,nb])
N=len(ptrs)
# ---------- hook (20:9800) ----------
class Asm:
    def __init__(s): s.b=bytearray(); s.lab={}; s.fix=[]
    def emit(s,*x): s.b+=bytes(x)
    def label(s,n): s.lab[n]=len(s.b)
    def br(s,op,n): s.b.append(op); s.fix.append((len(s.b),n)); s.b.append(0)
    def done(s):
        for pos,n in s.fix:
            rel=s.lab[n]-(pos+1); assert -128<=rel<=127,(n,rel); s.b[pos]=rel&255
        return bytes(s.b)
a=Asm()
TB=0xA000
a.emit(0x85,0xBB,0xC8,0xAF,0x04,0xFF,0x7F,0xC9,0x5A,0xD0,44,0xAF,0x00,0xFF,0x7F,0xC9,0xA6,0xD0,36)
a.emit(0xAF,0x01,0xFF,0x7F,0x85,0xB9,0xAF,0x02,0xFF,0x7F,0x85,0xBA,0xAF,0x03,0xFF,0x7F,0x85,0xBB,0xA9,0x00,0x8F,0x00,0xFF,0x7F,0xA9,0x00,0x8F,0x04,0xFF,0x7F,0xA0,0x00,0x00,0xC2,0x20,0x6B)
a.emit(0xC2,0x20,0x5A,0xDA,0xA9,0,0,0x48,0xA9,N&255,N>>8,0x48)
a.label('loop')
a.emit(0xA3,0x03,0xC3,0x01); a.br(0xB0,'nf')
a.emit(0x18,0x63,0x01,0x4A,0xA8,0x0A,0x48,0x0A,0x18,0x63,0x01,0xAA,0x68)
a.emit(0xE2,0x20,0xBF,(TB+2)&255,(TB+2)>>8,0x20,0xC5,0xBB,0xC2,0x20)
a.br(0xF0,'same'); a.br(0x90,'less')
a.label('greater'); a.emit(0x98,0x83,0x01); a.br(0x80,'loop')
a.label('less'); a.emit(0x98,0x1A,0x83,0x03); a.br(0x80,'loop')
a.label('same'); a.emit(0xBF,TB&255,TB>>8,0x20,0xC5,0xB9); a.br(0xF0,'found'); a.br(0x90,'less'); a.br(0x80,'greater')
a.label('found'); a.emit(0xBF,(TB+3)&255,(TB+3)>>8,0x20,0x85,0xB9,0xE2,0x20,0xBF,(TB+5)&255,(TB+5)>>8,0x20,0x85,0xBB,0xC2,0x20)
a.label('nf'); a.emit(0x68,0x68,0xFA,0x7A,0x6B)
code=a.done()
HOOK=0x101800
assert len(code)<0xC0,len(code)
d[HOOK:HOOK+len(code)]=code
def jslb(off):
    bank=0x20+((off-0x100000)>>15); ad=0x8000+((off-0x100000)&0x7FFF); return bytes([0x22,ad&255,ad>>8,bank])
HA=0x1018C0; HB=0x1018F0
hookA=bytes([0xAD,0x7B,0x18,0xC9,0xF1,0xD0,32,0xA9,0xA5,0x8F,0x00,0xFF,0x7F,0xA9,0x5A,0x8F,0x04,0xFF,0x7F,0xA5,0xB9,0x8F,0x01,0xFF,0x7F,0xA5,0xBA,0x8F,0x02,0xFF,0x7F,0xA5,0xBB,0x8F,0x03,0xFF,0x7F,0xA9,0xFF,0xC9,0xFF,0x6B])
hookB=bytes([0xAF,0x04,0xFF,0x7F,0xC9,0x5A,0xD0,23,0xAF,0x00,0xFF,0x7F,0xC9,0xA5,0xD0,15,0xA9,0x1D,0x8D,0xD5,0x17,0xA9,0xA6,0x8F,0x00,0xFF,0x7F,0xA0,0x00,0x00,0x6B,0xB7,0xB6,0x8D,0xD5,0x17,0xC8,0x6B])
d[HA:HA+len(hookA)]=hookA; d[HB:HB+len(hookB)]=hookB
assert bytes(d[0x6DC7:0x6DCC])==bytes([0xAD,0x7B,0x18,0xC9,0xFF])
d[0x6DC7:0x6DCC]=jslb(HA)+bytes([0xEA])
assert bytes(d[0x713F:0x7145])==bytes([0xB7,0xB6,0x8D,0xD5,0x17,0xC8])
d[0x713F:0x7145]=jslb(HB)+bytes([0xEA,0xEA])
# patch caller 00:EC43
o=0x6C43
assert bytes(d[o:o+5])==bytes([0x85,0xBB,0xC8,0xC2,0x20]),bytes(d[o:o+5]).hex()
d[o:o+5]=bytes([0x22,0x00,0x98,0x20,0xEA])
# ---------- menu template patches ----------
rowidx=json.load(open('/home/claude/emu/rowidx.json'))
tmpls=json.load(open('/home/claude/emu/templates.json'))
import tmpl2
for xo in (0x1E6B6,0x1E7F7,0x1E5C2):
    rr=tmpl2.parse(xo)
    if rr:
        for p,r in rr[0]: rowidx[str(p)]=[q for q,tt,a in r]
        tmpls.append([xo,[[p,[(q,tt,a) for q,tt,a in r]] for p,r in rr[0]],rr[1]])
for o,rs,end in tmpls:
    for p,r in rs:
        for q,tt,a in r:
            if tt in (0x3E,0x3F): d[q]=0x01
def prow(rowaddr,col,text):
    qs=rowidx[str(rowaddr)]
    for i,ch in enumerate(text):
        q=qs[col+i]; d[q]=CODE[ch]; d[q+1]=0x28
def pword(off,text):
    for i,ch in enumerate(text):
        d[off+2*i]=CODE[ch]; d[off+2*i+1]=0x28
MENU=[(0x1E6B6,1,"Target"),(0x4CD39,3,"Command"),(0x4CD6B,1," Talk Look"),(0x4CD9D,1," Cast Item"),(0x4CDCF,1," Team Gear"),
 (0x4D238,2,"Party"),(0x4D25E,1," Talk  "),(0x4D284,1," Status"),(0x4D2AA,1," Skills"),(0x4D2D0,1," Order "),
 (0x4DD23,2,"LV "),(0x4DDE9,2,"Str"),(0x4DE2B,2,"Skl"),(0x4DE6D,2,"Atk"),(0x4DEAF,2,"Def "),(0x4DEF1,2,"Agi "),(0x4DF33,2,"Exp "),(0x4DF75,2,"Next"),
 (0x4E770,1,"Item"),(0x4E78E,1," Use "),(0x4E7AC,1," Give"),(0x4E7CA,1," Drop"),
 (0x4EC4F,1,"Atk"),(0x4EC89,1,"Def "),
 (0x4F026,4,"Battle Magic"),(0x4F324,4,"Field Magic"),
 (0x4F67E,3,"Buy"),(0x4F6A0,3,"Sell"),
 (0x4FB9C,2,"Data"),(0x4FBD6,2,"No data "),(0x4FC10,2,"        "),(0x4FD4F,2,"Store"),(0x4FD71,2,"Take "),
 (0x1E85C,1," Power  "),(0x1E886,1," Normal "),
 (0x1E906,1,"Target"),(0x1E94B,1,"Target"),(0x1E9B2,1,"Target"),(0x1EA3B,1,"Target"),
 (0x1EB3F,1,"Magic"),(0x1EF05,1," Use "),(0x1EF23,1," Gear"),(0x1EF7B,1," RHnd"),(0x1EF99,1," LHnd"),
 (0x1EFD3,1,"Card "),(0x1EFF5,1," Show "),(0x1F017,1," No.  "),(0x1F9F3,1,"  Yes "),(0x1FA15,1,"  No  ")]
for ra,c,t in MENU: prow(ra,c,t)
# title/save screen (raw tilemap words)
for q in range(0x27800,0x27C00,2):
    if d[q]==0x3E and d[q+1]==0x28: d[q]=0x01
pword(0x27A08,"Speed"); pword(0x27A48,"Start"); pword(0x27A58," Fst Nrm Slw ")
for k,a in enumerate((0x27AF8,0x27B24,0x27B50)): pword(a,f"File{k+1}")

def pwx(off,jp_len,text):
    for k,ch in enumerate(text):
        o=off+2*k
        if k>=jp_len and d[o] not in (0x01,0x05):
            print('WARN pwx truncated',hex(off),text,k); break
        d[o]=CODE[ch]; d[o+1]=0x28
    for k in range(len(text),jp_len):
        d[off+2*k]=0x01; d[off+2*k+1]=0x28
for q in range(0x4CB00,0x50000,2):
    if d[q]==0x3E and d[q+1]==0x28: d[q]=0x01
for q in range(0x1E000,0x20000,2):
    if d[q]==0x3E and d[q+1]==0x28: d[q]=0x01
for off,jl,t in ((0x1FC6E,3,"Whose"),(0x1FD88,3,"Which"),(0x4CE61,3,"Mgc"),(0x4CF74,3,"Mgc"),(0x4D163,3,"Whom"),(0x4D33B,3,"Who"),
    (0x4D1D2,3,"Loc"),(0x4E5EF,3,"Item"),(0x4E728,3,"Whom"),(0x4E82F,3,"Whom"),(0x4E6C6,4,"Album"),(0x4E988,3,"Gear"),
    (0x4E9F9,2,"Right"),(0x4EF17,3,"Left"),(0x4EF6A,3,"Armor"),(0x4EFBD,3,"Helm"),(0x4EBCE,8,"No items"),
    (0x27850,10,"LacroaHero"),(0x27876,10,"Myth Giant"),(0x2789A,9,"ArgusKnts"),(0x278AC,8,"L.Knight"),(0x278C4,10,"No data   ")):
    pwx(off,jl,t)
# ---------- hardcoded battle labels in code ----------
def lda_sta(code,addr,x=False): return bytes([0xA9,code,0x9D if x else 0x8D,addr&255,addr>>8])
stubs=bytearray(); STUB=0x101A00
def add_stub(b):
    off=STUB+len(stubs); stubs.extend(b); return off
def jsl_bytes(off):
    bank=0x20+((off-0x100000)>>15); ad=0x8000+((off-0x100000)&0x7FFF); return bytes([0x22,ad&255,ad>>8,bank])
def stub_x(c1,c2=None):
    def body(t): return b''.join(lda_sta(CODE[ch],0x033F+2*k,True) for k,ch in enumerate(t))
    if c2 is None: return body(c1)+b'\x6B'
    b1=body(c1)+b'\x6B'; b2=body(c2)+b'\x6B'
    return bytes([0x8A,0x29,0x10,0xF0,len(b2)])+b2+b1
def patch_code(off,length,stub,rtl=False):
    so=add_stub(stub); j=jsl_bytes(so)
    blk=bytearray([0xEA])*length
    blk[0:4]=j
    if rtl: blk[4]=0x6B
    d[off:off+length]=blk
# group A: Fight (fixed cells)
sa=b''.join(lda_sta(CODE[ch],a) for ch,a in zip("Fight",(0x383,0x385,0x387,0x389,0x38B)))+b'\x6B'
assert bytes(d[0x1D977:0x1D979])==bytes([0xA9,0x1F])
patch_code(0x1D977,18,sa)
assert bytes(d[0x1D99D:0x1D99F])==bytes([0xA9,0x3E]); patch_code(0x1D99D,30,stub_x("Guard","Def"))
assert bytes(d[0x1D9C0:0x1D9C2])==bytes([0xA9,0x3E]); patch_code(0x1D9C0,25,stub_x("Item"))
assert bytes(d[0x1DA37:0x1DA39])==bytes([0xA9,0x54]); patch_code(0x1DA37,15,stub_x("Auto"))
assert bytes(d[0x1DA4B:0x1DA4D])==bytes([0xA9,0x25]); patch_code(0x1DA4B,20,stub_x("Flee"))
for off,ln,eng in ((0x1DAC0,16,("Aura",None)),(0x1DAD0,16,("Magic","Mgc")),(0x1DAE0,16,("Aura",None)),(0x1DAF0,21,("Crit",None)),(0x1DB05,26,("Combo","Cmbo")),(0x1DB1F,21,("Wink",None)),(0x1DB34,21,("Omen",None))):
    assert d[off]==0xA9 and d[off+ln-1] in (0x6B,0x04) or True
    patch_code(off,ln,stub_x(*eng),rtl=True)

# dead-status label (03:D2EA..D2FF): "Dead"
assert bytes(d[0x1D2EA:0x1D2EE])==bytes([0xA9,0x3E,0x9D,0xBB])
sd=lda_sta(CODE['D'],0x2F9,True)+bytes([0xA9,CODE['e'],0x85,0x06,0xA9,CODE['a'],0x85,0x05,0xA9,CODE['d'],0x85,0x04,0x6B])
patch_code(0x1D2EA,22,sd)
# Gold label
assert bytes(d[0x1E3A1:0x1E3A3])==bytes([0xA9,0x59])
d[0x1E3A2]=CODE['G']; d[0x1E3A7]=CODE['o']; d[0x1E3AC]=CODE['l']; d[0x1E3B1]=CODE['d']
assert bytes(d[0x1E3B5:0x1E3B7])==bytes([0xA9,0x3E]); d[0x1E3B6]=0x01
d[HOOK+0x300:HOOK+0x300]=b''
assert len(stubs)<0x600
# stubs live in bank 20 at 0x101A00
d[STUB:STUB+len(stubs)]=stubs
# ---------- fixed-width tables ----------
for f in sorted(glob.glob('/home/claude/emu/tr/*.tbl')):
    for ln in open(f,encoding='utf-8'):
        ln=ln.rstrip('\n')
        if not ln.strip() or ln.startswith('#'): continue
        off,w,t=ln.split('|',2); off=int(off,16); w=int(w)
        b=bytes(CODE[c] for c in t)
        assert len(b)<=w,(ln)
        b=b+bytes([0x01])*(w-len(b))
        d[off:off+w]=b

# ---------- character title/class table (8-byte entries) ----------
TITLES=[(0x309F1,"Zeon"),(0x30A07,"Knight"),(0x30A0F,"Warrior"),(0x30A17,"Monk"),(0x30A1F,"Fairy"),(0x30A27,"Fighter"),(0x30A2F,"Sorcerer"),
 (0x30A37,"Monster"),(0x30A3F,"Demon"),(0x30A47,"Mage"),(0x30A4F,"Warlock"),(0x30A57,"DarkEmp"),(0x30A5F,"Giant"),(0x30A67,"Priest"),
 (0x30A6F,"Spirit"),(0x30A77,"Soldier"),(0x30A7F,"Brawler"),(0x30A87,"Guard"),(0x30A8F,"Wizard"),(0x30A97,"King"),(0x30A9F,"Princess"),
 (0x30AA7,"Prince"),(0x30AAF,"Smith"),(0x30AB7,"Innkeep"),(0x30ABF,"Citizen"),(0x30AC7,"Prophet"),(0x30ACF,"Dancer"),(0x30AD7,"Retainer"),
 (0x30ADF,"Maid"),(0x30AE7,"Guards"),(0x30AEF,"Pegasus"),(0x30AF7,"Sage"),(0x30AFF,"Item"),(0x30B07,"Carddass")]
for off,t in TITLES:
    assert len(t)<=8
    d[off:off+8]=bytes(CODE[c] for c in t)+bytes([0x01])*(8-len(t))

# ---------- character full-name/title table (token based) ----------
from textlib import dec as jdec, d as dorig
NAMEMAP={"ナイトガンダム":"Gundam","バーサル":"Versal","スペリオル":"Superior","ドラゴン":"Dragon","せんし":"Warrior","ガンキャノン":"Cannon",
 "そうりょ":"Monk","ガンタンク":"Tank","ナイト":"Knight","アムロ":"Amuro","セイラ":"Sayla","ようせい":"Fairy","ジムスナイパー":"GMSnpr",
 "ぶとうか":"Fighter","ネモ":"Nemo","けんし":"Fencer","ゼータガンダム":"Zeta","とうし":"Fighter","ダブルゼータ":"ZZ","ほうじゅつし":"Sorcerer",
 "ニューガンダム":"Nu","アレックス":"Alex","フラウひめ":"Fraw","よげんしゃ":"Prophet","サラサ":"Sarasa","おうごんのきし":"G.Knight"}
i=0x31340; END=0x31470; TOK=[]
while i<END:
    if dorig[i] in (0x01,0x00): i+=1; continue
    j=i
    while j<END and dorig[j] not in (0x01,0x00): j+=1
    TOK.append((i,j)); i=j
SHORT={"ナイト":"Knt","ドラゴン":"Drgn","ぶとうか":"Fist","とうし":"Fgt","けんし":"Swd","ナイトガンダム":"Gundam","ジムスナイパー":"GMSnpr","ほうじゅつし":"Sorcer"}
def split_known(jp):
    # DP over known words (longest first)
    keys=sorted(NAMEMAP,key=len,reverse=True)
    best={0:[]}
    for p in range(len(jp)):
        if p not in best: continue
        for k in keys:
            if jp.startswith(k,p) and (p+len(k)) not in best: best[p+len(k)]=best[p]+[(p,k)]
    return best.get(len(jp))
for n,(s,e) in enumerate(TOK):
    jp=jdec(bytes(dorig[s:e]))
    parts=split_known(jp)
    if not parts: continue
    nxt=TOK[n+1][0] if n+1<len(TOK) else END
    for pi,(p,k) in enumerate(parts):
        ps=s+p
        if pi+1<len(parts): room=len(k)
        else: room=max(len(k),nxt-ps-1)
        t=NAMEMAP[k]
        if len(t)>room: t=SHORT.get(k,t)[:room]
        d[ps:ps+room]=bytes(CODE[c] for c in t)+bytes([0x01])*(room-len(t))
# ailment labels in battle status box (03:D49A table, 5 entries x 3 tiles) + dakuten helper routines
_orig_tbl=bytes([0x23,0x17,0x01, 0x6E,0x6A,0x01, 0x3D,0x36,0x3D, 0x1D,0x21,0x01, 0x28,0x14,0x01])
assert bytes(d[0x1D49A:0x1D49A+15])==_orig_tbl
for _i,_w in enumerate(("Psn","Par","Cnf","Stn","Slp")):
    d[0x1D49A+_i*3:0x1D49A+_i*3+3]=bytes(CODE[c] for c in _w)
# routines at D472(11b) D47D(6b) D483(6b) D489(11b) D494(6b): write blank under-tile only (no dakuten marks)
for _o,_n in ((0x1D472,11),(0x1D47D,6),(0x1D483,6),(0x1D489,11),(0x1D494,6)):
    assert d[_o]==0xA9
    d[_o:_o+_n]=(bytes([0xA9,0x01,0x9D,0xF9,0x02,0x6B])+bytes([0xEA])*_n)[:_n]
import title
print('title:',title.apply(d,rle_m,unrle_m,cur))
# ---------- checksum ----------
d[0x7FDC:0x7FE0]=bytes([0xFF,0xFF,0x00,0x00])
cs=sum(d)&0xFFFF
d[0x7FDE]=cs&255;d[0x7FDF]=cs>>8
ck=cs^0xFFFF; d[0x7FDC]=ck&255;d[0x7FDD]=ck>>8
out=sys.argv[1] if len(sys.argv)>1 else '/home/claude/emu/out/test.sfc'
open(out,'wb').write(d)
print('built',out,'segments translated:',N,'font bytes',len(enc),'text end',hex(cur),'hook',len(code),'bytes')
