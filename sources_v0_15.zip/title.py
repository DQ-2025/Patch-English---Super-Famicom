# Tela de título: logos em inglês (BG1 4bpp + legenda em sprites)
import numpy as np
from gen_logo import build as build_logo
from gen_sub import sub_canvas
LOGO_NEW=0x11A000   # 23:A000
SUB_NEW =0x11D000   # 23:D000
def lorom_ptr(off): return bytes([(0x8000+off%0x8000)&255,(0x8000+off%0x8000)>>8,0x20+(off-0x100000)//0x8000])
def tile_enc(t):
    b=bytearray(32)
    for y in range(8):
        p=[0,0,0,0]
        for x in range(8):
            v=int(t[y][x])
            for k in range(4): p[k]|=((v>>k)&1)<<(7-x)
        b[2*y]=p[0];b[2*y+1]=p[1];b[16+2*y]=p[2];b[17+2*y]=p[3]
    return bytes(b)
def apply(d,rle_m,unrle_m,text_end):
    assert text_end<=LOGO_NEW
    # ---- logo (BG1) ----
    ro=0xF0B31; assert d[0x3C4:0x3C7]==bytes([0x31,0x8B,0x1E]) and d[0x3C7]==0xF5 and d[0x3C8:0x3CA]==bytes([0,0x16])
    st=bytearray(unrle_m(bytes(d[ro:ro+0x3000]),0x1600,0xF5))
    g=build_logo("Knight Gundam Story","SD Gundam Gaiden",big_bold=3,top_bold=3,big_space=28,top_space=20)
    cells={0:range(6,18),1:range(6,18),2:range(1,24),3:range(0,24),4:range(1,24),5:range(1,24)}
    ids={}; nxt=0x39; entries=[]
    for r in range(6):
        row=[]
        for c in range(24):
            if c not in cells[r]:
                assert not g[r*8:r*8+8,c*8:c*8+8].any(); continue
            t=g[r*8:r*8+8,c*8:c*8+8]
            if not t.any(): row.append(0x0800); continue
            k=t.tobytes()
            if k not in ids:
                ids[k]=nxt; assert nxt<=0xAA,'tiles demais'; st[nxt*32:nxt*32+32]=tile_enc(t); nxt+=1
            row.append(ids[k]|0x0C00)
        entries.append(row)
    # tilemap em ROM: 6 segmentos [header][entradas...][FFFF]
    p=0x903E4; counts=[12,12,23,24,23,23]; segs=[]
    while len(segs)<6:
        q=p+2
        while d[q:q+2]!=b'\xff\xff': q+=2
        n=(q-p-2)//2
        if n>0: segs.append((p,n))
        p=q+2
    assert [n for _,n in segs]==counts,segs
    for (p,n),row in zip(segs,entries):
        assert len(row)==n
        for i,e in enumerate(row): d[p+2+2*i:p+4+2*i]=bytes([e&255,e>>8])
    enc=rle_m(bytes(st),0xF5); assert unrle_m(enc,0x1600,0xF5)==bytes(st)
    assert all(b==0xFF for b in d[LOGO_NEW:LOGO_NEW+len(enc)]) and len(enc)<0x3000
    d[LOGO_NEW:LOGO_NEW+len(enc)]=enc; d[0x3C4:0x3C7]=lorom_ptr(LOGO_NEW)
    # ---- legenda (sprites, paleta 7) ----
    ro2=0xA2D8F; assert d[0x4A2:0x4A5]==bytes([0x8F,0xAD,0x14]) and d[0x4A5]==0xEA
    ss=bytearray(unrle_m(bytes(d[ro2:ro2+0x3000]),0x1000,0xEA))
    cv=sub_canvas("The Great Legacy",bold=0,space=18)
    for c in range(11):
        for r in range(2):
            ss[(c+16*r)*32:(c+16*r)*32+32]=tile_enc(cv[r*8:r*8+8,c*8:c*8+8])
    enc2=rle_m(bytes(ss),0xEA); assert unrle_m(enc2,0x1000,0xEA)==bytes(ss)
    assert all(b==0xFF for b in d[SUB_NEW:SUB_NEW+len(enc2)]) and len(enc2)<0x3000
    d[SUB_NEW:SUB_NEW+len(enc2)]=enc2; d[0x4A2:0x4A5]=lorom_ptr(SUB_NEW)
    return len(ids),len(enc),len(enc2)
