import numpy as np, json
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from style import shift
DJ='/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed-Bold.ttf'
INTER='/usr/share/fonts/opentype/inter/Inter-Black.otf'
def text_mask(txt,font,box_w,box_h,bold=0,S=8,top_pad=0,space=0):
    """Renderiza txt no tamanho exato box_w x box_h (anisotrópico), mascara bool."""
    f=ImageFont.truetype(font,200)
    W=int(sum(f.getlength(c)+space for c in txt))+80; H=400
    im=Image.new('L',(W,H),0); d=ImageDraw.Draw(im); x=40
    for c in txt:
        d.text((x,100),c,font=f,fill=255); x+=f.getlength(c)+space
    bb=im.getbbox(); im=im.crop(bb)
    if bold: im=im.filter(ImageFilter.MaxFilter(bold))
    bb=im.getbbox(); im=im.crop(bb)
    im=im.resize((box_w,box_h),Image.BOX if False else Image.LANCZOS)
    a=np.array(im)>110
    return a
def dil4(a):
    o=a.copy()
    for dx,dy in((-1,0),(1,0),(0,-1),(0,1)): o|=shift(a,dx,dy)
    return o
def big(F,bands):
    base=dil4(F); E=np.zeros_like(F)
    for k in (1,2): E|=shift(base,k,k)
    gray=E&~base; outer=dil4(gray)&~(gray|base)
    out=np.zeros(F.shape,int); out[outer]=1; out[base]=1; out[gray]=2
    for y in range(F.shape[0]): out[y][F[y]]=bands[y]
    return out
def small(F,bands):
    base=dil4(F)|(shift(F,1,1)&False)
    out=np.zeros(F.shape,int); out[base]=1
    for y in range(F.shape[0]): out[y][F[y]]=bands[y]
    return out
BANDS_BIG={y:b for y,b in zip(range(2,28),[3]*4+[4]*3+[5]*3+[6]*3+[7]*3+[8]*3+[9]*3+[10]*4)}
BANDS_SM={y:(14 if y<=7 else 13) for y in range(1,15)}
def build(big_txt,top_txt,big_font=DJ,top_font=DJ,big_box=(176,26),top_box=(90,12),big_bold=0,top_bold=0,big_space=0,top_space=0):
    g=np.zeros((48,192),int)
    # logo grande: rosto ocupa x 9..(9+w) , y 2..27 dentro da janela 32 linhas (offset 16)
    F=np.zeros((32,192),bool)
    m=text_mask(big_txt,big_font,*big_box,bold=big_bold,space=big_space)
    F[2:2+big_box[1],10:10+big_box[0]]=m
    bands={y:BANDS_BIG.get(y,10) for y in range(32)}
    bg=big(F,bands); g[16:48]=bg
    # logo pequeno: janela 16 linhas, x 48..143
    F2=np.zeros((16,192),bool)
    m2=text_mask(top_txt,top_font,*top_box,bold=top_bold,space=top_space)
    x0=48+ (96-top_box[0])//2
    F2[2:2+top_box[1],x0:x0+top_box[0]]=m2
    bands2={y:BANDS_SM.get(y,13) for y in range(16)}
    g[0:16]=small(F2,bands2)
    return g
PAL={0:(255,0,255),1:(0,0,0),2:(98,98,98),3:(0,131,131),4:(16,156,156),5:(32,189,189),6:(49,230,230),7:(123,255,255),8:(148,255,255),9:(189,255,255),10:(255,255,255),13:(255,115,90),14:(255,156,131)}
def preview(g,fn,scale=5):
    h,w=g.shape; im=Image.new('RGB',(w,h)); px=im.load()
    for y in range(h):
        for x in range(w): px[x,y]=PAL.get(int(g[y,x]),(255,0,255))
    im.resize((w*scale,h*scale),Image.NEAREST).save(fn)
if __name__=='__main__':
    g=build("Knight Gundam Story","SD Gundam Gaiden",big_bold=3,top_bold=3,big_space=28,top_space=20)
    preview(g,'logo_new.png')
