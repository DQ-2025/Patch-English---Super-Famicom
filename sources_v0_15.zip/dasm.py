import sys
d=open('/home/claude/emu/game.sfc','rb').read()
def off(b,a): return ((b&0x7f)*0x8000+(a&0x7fff))%len(d)
# opcode table: (mnemonic, mode)
M={}
def add(op,mn,mode): M[op]=(mn,mode)
g1=['ORA','AND','EOR','ADC','STA','LDA','CMP','SBC']
modes1=['(dp,X)','dp','imm','abs','(dp),Y','dp,X','abs,Y','abs,X']
for a in range(8):
    for b in range(8):
        add(a*32+b*4+1,g1[a],modes1[b])
modes3=['sr,S','[dp]',None,'long',  '(sr,S),Y','[dp],Y',None,'long,X']
for a in range(8):
    for b in range(8):
        if modes3[b]: add(a*32+b*4+3,g1[a],modes3[b])
for a in range(8): add(a*32+0x12,g1[a],'(dp)')
add(0x89,'BIT','imm')
sh=['ASL','ROL','LSR','ROR']
for i,n in enumerate(sh):
    add(i*32+0x0A,n,'A'); add(i*32+0x06,n,'dp'); add(i*32+0x16,n,'dp,X'); add(i*32+0x0E,n,'abs'); add(i*32+0x1E,n,'abs,X')
for op,n in ((0x1A,'INC'),(0x3A,'DEC')): add(op,n,'A')
for n,base in (('INC',0xE6),('DEC',0xC6)):
    add(base,n,'dp'); add(base+0x10,n,'dp,X'); add(base+8,n,'abs'); add(base+0x18,n,'abs,X')
for op,n,m in ((0x24,'BIT','dp'),(0x34,'BIT','dp,X'),(0x2C,'BIT','abs'),(0x3C,'BIT','abs,X'),(0x04,'TSB','dp'),(0x0C,'TSB','abs'),(0x14,'TRB','dp'),(0x1C,'TRB','abs')): add(op,n,m)
for op,n in ((0x10,'BPL'),(0x30,'BMI'),(0x50,'BVC'),(0x70,'BVS'),(0x90,'BCC'),(0xB0,'BCS'),(0xD0,'BNE'),(0xF0,'BEQ'),(0x80,'BRA')): add(op,n,'rel')
add(0x82,'BRL','rel16')
for op,n in ((0x18,'CLC'),(0x38,'SEC'),(0x58,'CLI'),(0x78,'SEI'),(0xB8,'CLV'),(0xD8,'CLD'),(0xF8,'SED'),(0xFB,'XCE'),(0xEA,'NOP'),(0xE8,'INX'),(0xC8,'INY'),(0xCA,'DEX'),(0x88,'DEY'),(0x60,'RTS'),(0x6B,'RTL'),(0x40,'RTI'),(0x48,'PHA'),(0x08,'PHP'),(0xDA,'PHX'),(0x5A,'PHY'),(0x68,'PLA'),(0x28,'PLP'),(0xFA,'PLX'),(0x7A,'PLY'),(0x8B,'PHB'),(0x0B,'PHD'),(0x4B,'PHK'),(0xAB,'PLB'),(0x2B,'PLD'),(0xAA,'TAX'),(0xA8,'TAY'),(0x8A,'TXA'),(0x98,'TYA'),(0x9B,'TXY'),(0xBB,'TYX'),(0x5B,'TCD'),(0x7B,'TDC'),(0x1B,'TCS'),(0x3B,'TSC'),(0xBA,'TSX'),(0x9A,'TXS'),(0xEB,'XBA'),(0xCB,'WAI'),(0xDB,'STP')): add(op,n,'imp')
add(0xC2,'REP','imm8'); add(0xE2,'SEP','imm8'); add(0x00,'BRK','imm8'); add(0x02,'COP','imm8'); add(0x42,'WDM','imm8')
for op,n,m in ((0xE0,'CPX','immx'),(0xE4,'CPX','dp'),(0xEC,'CPX','abs'),(0xC0,'CPY','immx'),(0xC4,'CPY','dp'),(0xCC,'CPY','abs'),
 (0x4C,'JMP','abs'),(0x5C,'JML','long'),(0x6C,'JMP','(abs)'),(0x7C,'JMP','(abs,X)'),(0xDC,'JML','[abs]'),(0x20,'JSR','abs'),(0xFC,'JSR','(abs,X)'),(0x22,'JSL','long'),
 (0xA2,'LDX','immx'),(0xA6,'LDX','dp'),(0xB6,'LDX','dp,Y'),(0xAE,'LDX','abs'),(0xBE,'LDX','abs,Y'),(0xA0,'LDY','immx'),(0xA4,'LDY','dp'),(0xB4,'LDY','dp,X'),(0xAC,'LDY','abs'),(0xBC,'LDY','abs,X'),
 (0x86,'STX','dp'),(0x96,'STX','dp,Y'),(0x8E,'STX','abs'),(0x84,'STY','dp'),(0x94,'STY','dp,X'),(0x8C,'STY','abs'),(0x64,'STZ','dp'),(0x74,'STZ','dp,X'),(0x9C,'STZ','abs'),(0x9E,'STZ','abs,X'),
 (0x54,'MVN','blk'),(0x44,'MVP','blk'),(0xF4,'PEA','abs'),(0xD4,'PEI','dp'),(0x62,'PER','rel16')): add(op,n,m)
def dis(bank,addr,n,m8=True,x8=True):
    out=[]
    for _ in range(n):
        o=off(bank,addr); op=d[o]
        if op not in M: out.append(f"{bank:02X}:{addr:04X}  .db {op:02X}"); addr+=1; continue
        mn,mode=M[op]
        ln=1; 
        if mode in('imm',):
            ln=2 if m8 else 3
        elif mode=='immx': ln=2 if x8 else 3
        elif mode in('imm8','dp','dp,X','dp,Y','(dp)','(dp,X)','(dp),Y','[dp]','[dp],Y','sr,S','(sr,S),Y','rel'): ln=2
        elif mode in('abs','abs,X','abs,Y','(abs)','(abs,X)','[abs]','rel16'): ln=3
        elif mode in('long','long,X'): ln=4
        elif mode=='blk': ln=3
        b=d[o+1:o+ln]
        v=int.from_bytes(b,'little')
        if mode=='imm' or mode=='immx': s=f"#${v:0{2*(ln-1)}X}"
        elif mode=='imm8': s=f"#${v:02X}"
        elif mode=='rel':
            t=(addr+2+(v-256 if v>127 else v))&0xFFFF; s=f"${t:04X}"
        elif mode=='rel16':
            t=(addr+3+(v-65536 if v>32767 else v))&0xFFFF; s=f"${t:04X}"
        elif mode=='imp': s=''
        elif mode=='A': s='A'
        elif mode=='blk': s=f"${d[o+2]:02X},${d[o+1]:02X}"
        else:
            s=mode.replace('dp',f"${v:02X}").replace('abs',f"${v:04X}").replace('long',f"${v:06X}").replace('sr',f"${v:02X}")
        out.append(f"{bank:02X}:{addr:04X}  {' '.join(f'{x:02X}' for x in d[o:o+ln]):<12} {mn} {s}")
        if mn=='REP':
            if v&0x20:m8=False
            if v&0x10:x8=False
        if mn=='SEP':
            if v&0x20:m8=True
            if v&0x10:x8=True
        addr+=ln
    return out
if __name__=='__main__':
    bank=int(sys.argv[1],16); addr=int(sys.argv[2],16); n=int(sys.argv[3])
    m8=sys.argv[4]!='16' if len(sys.argv)>4 else True
    x8=sys.argv[5]!='16' if len(sys.argv)>5 else True
    print('\n'.join(dis(bank,addr,n,m8,x8)))
