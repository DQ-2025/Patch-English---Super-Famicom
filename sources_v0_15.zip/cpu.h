#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
typedef uint8_t u8; typedef uint16_t u16; typedef uint32_t u32;
extern u8 *rom; extern u32 romsize;
extern u8 wram[0x20000]; extern u8 sram[0x8000];
extern u16 A,X,Y,S,D,PC; extern u8 DB,PB,P,E;
extern int waiting, stopped;
extern long cycles;
extern u8 *romtrace; extern int tracing; extern int dataread;
u8 read8(u32 a); void write8(u32 a,u8 v);
void cpu_reset(void); int cpu_step(void);
void cpu_nmi(void); void cpu_irq(void);
