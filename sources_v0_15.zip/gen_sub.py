import numpy as np
from gen_logo import text_mask, DJ, INTER
from style import shift
from PIL import Image
def sub_canvas(txt,box=(85,13),bold=3,space=14,font=DJ):
    F=np.zeros((16,88),bool)
    m=text_mask(txt,font,box[0],box[1],bold=bold,space=space)
    F[0:box[1],0:box[0]]=m
    sh=shift(F,1,1)&~F
    gold=F&(~shift(F,1,0)|~shift(F,0,1))
    out=np.zeros((16,88),int); out[sh]=8; out[F]=1; out[gold]=5
    return out
PALS={0:(255,0,255),1:(213,213,0),5:(172,139,0),8:(98,49,0)}
def prev(g,fn,sc=10):
    h,w=g.shape; im=Image.new('RGB',(w,h)); px=im.load()
    for y in range(h):
        for x in range(w): px[x,y]=PALS.get(int(g[y,x]),(255,0,255))
    im.resize((w*sc,h*sc),Image.NEAREST).save(fn)
if __name__=='__main__':
    prev(sub_canvas("The Great Legacy"),'sub_new.png')
