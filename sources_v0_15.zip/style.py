import numpy as np
def shift(a,dx,dy):
    o=np.zeros_like(a); H,W=a.shape
    ys=slice(max(dy,0),H+min(dy,0)); yd=slice(max(-dy,0),H+min(-dy,0))
    xs=slice(max(dx,0),W+min(dx,0)); xd=slice(max(-dx,0),W+min(-dx,0))
    o[ys,xs]=a[yd,xd]; return o
def dil8(a):
    o=a.copy()
    for dx in(-1,0,1):
        for dy in(-1,0,1): o|=shift(a,dx,dy)
    return o
def big_style(F,bands,ext=2):
    """F bool mask do rosto. bands: dict y->idx (rosto). retorna array de índices 0..15"""
    base=dil8(F)
    E=np.zeros_like(F)
    for k in range(1,ext+1): E|=shift(base,k,k)
    gray=E&~base
    outer=dil8(gray)&~(gray|base)
    H,W=F.shape; out=np.zeros((H,W),int)
    out[outer]=1; out[base]=1; out[gray]=2
    for y in range(H):
        for x in range(W):
            if F[y,x]: out[y,x]=bands[y]
    return out
