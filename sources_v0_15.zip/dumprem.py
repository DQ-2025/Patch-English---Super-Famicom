import json,sys,glob
sys.path.insert(0,'/home/claude/emu')
from textlib import *
segs=json.load(open('segs.json'))
tr=set()
for f in glob.glob('tr/*.txt'):
    for ln in open(f,encoding='utf-8'):
        if '|' in ln and not ln.startswith('#'): tr.add(int(ln.split('|')[0],16))
rem=[(s,e) for s,e in segs if s not in tr]
a=int(sys.argv[1]); n=int(sys.argv[2])
print(len(rem),'remaining')
for s,e in rem[a:a+n]:
    t=dec(d[s:e]).replace(chr(10),'/')
    if len(t)<9 and t.strip('<>ENDFM0123456789ABCDEF ')=='' : t='(skip)'+t
    print(f"{s:X}|{t}")
