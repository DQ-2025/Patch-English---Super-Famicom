import sys
def apply(rom,ips):
    d=bytearray(rom); assert ips[:5]==b'PATCH'; p=5
    while ips[p:p+3]!=b'EOF':
        off=int.from_bytes(ips[p:p+3],'big'); sz=int.from_bytes(ips[p+3:p+5],'big'); p+=5
        if sz==0:
            rl=int.from_bytes(ips[p:p+2],'big'); v=ips[p+2]; p+=3; data=bytes([v])*rl
        else: data=ips[p:p+sz]; p+=sz
        if off+len(data)>len(d): d+=bytes(off+len(data)-len(d))
        d[off:off+len(data)]=data
    return d
def make(a,b):
    # a,b bytearrays; b>=a length
    recs=[];i=0;n=len(b)
    a=bytes(a)+bytes(max(0,n-len(a)))
    while i<n:
        if a[i]==b[i]: i+=1;continue
        j=i;gap=0
        while j<n:
            if a[j]!=b[j]: gap=0
            else:
                gap+=1
                if gap>8: break
            j+=1
        j-=gap if j<n or gap else 0
        j=i
        k=i;last=i
        while k<n and k-last<=8:
            if a[k]!=b[k]: last=k
            k+=1
        end=last+1
        recs.append((i,bytes(b[i:end])));i=end
    out=bytearray(b'PATCH')
    for off,data in recs:
        for s in range(0,len(data),0xFFFF):
            ch=data[s:s+0xFFFF]; o=off+s
            if o==0x454F46: o-=1; ch=bytes([b[o]])+ch  # avoid EOF marker
            if len(ch)>=8 and len(set(ch))==1:
                out+=o.to_bytes(3,'big')+b'\0\0'+len(ch).to_bytes(2,'big')+ch[:1]
            else: out+=o.to_bytes(3,'big')+len(ch).to_bytes(2,'big')+ch
    out+=b'EOF'; return bytes(out)
